#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 16:31:30 2018

@author: armano
"""

# -----------------------------------------------------------------------------

from datastream.loader import Loader

# -----------------------------------------------------------------------------

class about(object):

  "Information handler utility for getting information about datasets"
  
  dpath  = '/home/armano/Programming/python/datasets/neuralnets/'
  #dpath  = '/Users/armano/Programming/python/datasets/neuralnets/'
  
  loader = Loader(path=dpath,source='datasets.info') # uses the loader ...
  
  @classmethod
  def difficulty(cls,*args):
    "Enumerate datasets according to the difficulty (delegates the loader)"
    cls.loader.enum(difficulty=args)

  def __init__(self,dname=None,version=None,verbose=False,at=10,path=''):
    "Init the information handler"
    if path: self.dpath = path
    about.reload()
    if not dname: return
    self.dname = dname
    if type(dname) in (tuple,list): dname, version = dname
    self.data, self.labels, self.info = self.loader.get(dname,version)
    self.info.display()
    if not verbose: return
    self.display_data(at=at)
    self.display_labels(at=at)
      
  @classmethod
  def reload(cls,path=''):
    if path: cls.dpath = path
    cls.loader = Loader(path=cls.dpath,source='datasets.info')
      
  def display_data(self,at=10):
    "Display data of a dataset (given as parameter)"
    print("\nData:\n")
    for k, d in enumerate(self.data):
      if k == at: break
      print("[ {} ... ]".format(str(d[:5])[1:-1]))
    
  def display_labels(self,at=10):
    "Display labels of a dataset (given as parameter)"
    print("\nLabels:\n {}".format(self.labels[:at]))

# -----------------------------------------------------------------------------
  
if __name__ == '__main__':

  
  about('iris')
  
  about('SPECT-full',verbose=True)
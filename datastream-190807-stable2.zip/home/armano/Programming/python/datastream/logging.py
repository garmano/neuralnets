#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat May 11 16:07:00 2019

@author: armano
"""

# -----------------------------------------------------------------------------

import os

# -----------------------------------------------------------------------------

from utils.date            import get_current_date, current_date

# -----------------------------------------------------------------------------

class logger(object):
  
  cdate = current_date(format='tiny')
  
  bpath = '../experiment summaries/batchfiles/'
  epath = '../experiments/runs {}/'.format(cdate)  
  lpath = '../experiment summaries/logfiles/runs {}/'.format(cdate)
  
  path_selector = { 'batch': bpath, 'exp':epath, 'summaries': lpath}
  
  if not os.path.exists(epath): os.makedirs(epath)
  if not os.path.exists(lpath): os.makedirs(lpath)

  @classmethod
  def get_path(cls,which):
    return cls.path_selector[which]

  @classmethod
  def get_paths(cls,*which):
    if not which: which = ('batch','exp','summaries')
    return [ cls.path_selector[p] for p in which ]

  @classmethod
  def set_logfile(cls,name='logger',context='summaries',version=''):
    "Give a name to the logger (logfile)"
    path = cls.get_path(context)
    cdate = get_current_date(remove='ss',strip=':')
    return f"{path}{name}-{cdate}{version}.log"

# -----------------------------------------------------------------------------


if __name__ == '__main__':
  
  
  print("\n*** Paths ***")
  
  for p in logger.paths(): print(p)
  
  print("\n*** Logger ***")
  print(logger.set_logfile())
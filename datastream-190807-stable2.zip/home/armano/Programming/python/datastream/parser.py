#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 30 15:21:27 2018

@author: armano
"""

# -----------------------------------------------------------------------------

class parser(object):
  
  "Generic class for parsing files of commands, results, etc"
  
  def __init__(self,infile=None,path=''):
    "Init the parser"
    self.infile, self.path = infile, path
    self.buffer = list()

  def load(self,comment="Loading file:"):
    "Load file content (i.e., get multiple commands)"
    print(comment,self.path+self.infile)
    with open(self.path+self.infile) as infile:
      self.buffer = [ line.strip() for line in infile if line is not '\n' ]
    return self
  
  def __lshift__(self,command):
    "Get a single command from string parameter"
    self.buffer = [ line.strip() for line in command.split('\n')]
    return self

  def parse(self):
    "Parse file content"
    raise Exception() # MUST be implemented by subclasses ...
  
  def get_commands(self):
    "Get commands from file (uses yield)"
    commands = list()
    for line in self.buffer:
      if not line: continue # just in case ...
      if line.find('@') == 0: # there MUST be a '@' as first character ...
        if commands: yield " ".join(commands)
        commands = list()
      commands += [ line ]
    yield " ".join(commands)

# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  pass
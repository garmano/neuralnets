#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 14:07:07 2019

@author: armano
"""

# -----------------------------------------------------------------------------

from datastream.loader    import Loader

from utils.iterables      import unzip2

# -----------------------------------------------------------------------------

class TextLoader(Loader):
  
  formatter = { 'inline': lambda self: self.encode_inline_samples }
  
  def encode_samples(self,content, sep='|', format='inline'):
    "Encode samples (from text to list of csv lines)"
    return self.formatter(format)(content,sep=sep)

  def encode_inline_samples(self,content,sep='|'):
    "Encode inline samples (one line = one document)"
    labels, docs = unzip2([ line.strip().split(sep) for line in content ])
    return    

    
# -----------------------------------------------------------------------------

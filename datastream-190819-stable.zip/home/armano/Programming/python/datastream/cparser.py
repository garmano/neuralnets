#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 30 15:21:27 2018

@author: armano
"""

# -----------------------------------------------------------------------------

from datastream.parser  import parser

from mining.constraints import make_constraints

# -----------------------------------------------------------------------------

def repeat(num_runs): return num_runs

def do(**kwargs): return kwargs
def netargs(**kwargs): return kwargs
def xtrargs(**kwargs): return kwargs

# -----------------------------------------------------------------------------

class run_info(object):
  
  "Stores information about a given experiment (possibly repeated many times)"
  
  def __init__(self, repeat, doargs, netargs,xtrargs=dict()):
    self.repeat  = repeat
    self.doargs  = doargs
    self.netargs = netargs
    self.xtrargs = xtrargs
    
  def display(self):
    print(f"Number of repeats: {self.repeat}")
    print(f"Do    args: {self.doargs}")
    print(f"Net   args: {self.netargs}")
    print(f"eXtra args: {self.xtrargs}")
    
# -----------------------------------------------------------------------------

class run_handler(object):
  
  "Stores information about the experiments to be done"
  
  def __init__(self,dname):
    "Init the container that stores information about runs"
    self.dname = dname
    self.runs  = list()
    self.constraints = list()
    
  def __lshift__(self,run):
    "Add a further run ..."
    self.runs += [ run ]
    
  def set_constraints(self,constraints):
    "Set the constraints that must apply to all runs"
    self.constraints = constraints
  
  def display(self, comment = 'Information about runs'):
    "Display information about the required runs"
    print(f"\n*** {comment} ({self.dname}) ***")
    for run in self.runs:
      print() ; run.display()

# -----------------------------------------------------------------------------

class cmd_parser(parser):
  
  "Utility to run experiments in batch mode"
  
  def __init__(self, batchfile=None, path=''):
    "Init the batch commands parser"
    super().__init__(batchfile,path)
    if batchfile: self.load() # automatically loads the commands ...

  def parse(self):
    "Parse the batch file content"
    commands = list()
    for command in self.get_commands():
      if '@dataset' in command:
        if "--skip" in command: continue
        dname = self.get_dataset_name(command)
        expected = self.get_dataset_constraints(command)
        annotations = self.get_dataset_annotations(command)
        handler = run_handler(dname)
        handler.set_constraints(expected)
        [ handler << run_info(*ann) for ann in annotations ]
        commands += [ handler ]
    return commands
  
  def get_dataset_name(self,command):
    "Get the dataset name and annotations"
    __, dname, *more = command.split() # dataset name is after "@dataset"
    return eval(dname)

  def get_dataset_constraints(self,command):
    "Get the constraints that must apply to a dataset"
    constraints = { 'spec': lambda s: s >= 0., 'sens': lambda s: s >= 0. }
    if "--expected" not in command: return constraints
    beg = command.find('expected') ; end = command.find(')',beg)
    expected = command[beg:end+1]
    return make_constraints(expected)

  def get_dataset_annotations(self,command):
    "Get the commands related to a dataset"
    annotations, cmd = list(), tuple()
    ndx = command.find('--repeat')
    assert ndx >= 0
    for item in command[ndx:].split('--')[1:]:
      if "repeat" in item: # each run command MUST start with 'repeat' ...
        if cmd:
          annotations += [ tuple(eval(c) for c in cmd) ]
          cmd = tuple()
      cmd += (item,)
    annotations += [ tuple(eval(c) for c in cmd) ]
    return annotations

# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  bpath = "../experiment summaries/batchfiles/"
  
  p = cmd_parser(path=bpath)
  
  commands = p.parse()
  
  [ cmd.display() for cmd in commands ]
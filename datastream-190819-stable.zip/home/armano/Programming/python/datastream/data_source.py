#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 22 16:27:55 2018

@author: armano
"""

# TO BE DONE SOONER OR LATER ...

class dataSource(object):
  
  "Data handler for training ML algorithms"
  
  def __init__(self, data, labels, indexes=None, balanced=True):
    self.data   = data   if not indexes else data[indexes]
    self.labels = labels if not indexes else labels[indexes]
    self.num_samples, self.num_attrs = data.shape
    self.neg_count, self.pos_count = 0, 0
    self.neg_data, self.pos_data = self.data[labels==-1], self.data[labels==+1]
    self.num_neg, self.num_pos = len(self.neg_data), len(self.pos_data)
 
  def __iter__(self):
    if not self.balanced: return iter(zip(self.data,self.labels))
    outdata = list()
    majority_class = self.check_equality(self.num_neg,self.num_pos)
    
    if maj_class == 0 or not self.balanced: return iter(zip(self.data,self.labels))
    outdata = list()
    maj_data, min_data = self.neg_data, self.pos_data
    if majority_class == +1: maj_data, min_data = min_data, maj_data
    for sample, label in zip()
      
    
  def check_equality(self,a,b):
    if a == b: return 0
    elif a > b: return -1
    else: return +1


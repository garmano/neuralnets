#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb  7 10:43:23 2018

@author: giuliano
"""

import numpy as np

from utils.strings import conditional_eval, strip_multiple


# -----------------------------------------------------------------------------
# ------------------------ DATASET --------------------------------------------
# -----------------------------------------------------------------------------

class datainfo(object):
  
  "Dataset information"
  
  __defaults__ = { 'name': (str,''), 'description': (str,''),
                   'sep': (str,','), 'index': (int,-1), 'header': (bool,True), 
                   'filename': (str,''), 'ext': (str,'csv'),
                   'classes': (tuple,('1','0')), 'fnames': (list,[]),
                   'num_attrs': (int,0), 'exclude': (tuple,None),
                   'num_neg': (int,0), 'num_pos': (int,0), 
                   'num_samples': (int,0), 'dratio' : (float,np.nan),
                   'difficulty': (str,'unknown'),
                   'embedding': (dict,{}),
                   'unknown_as': (type(None),None)}

  __slots__ = tuple([slot for slot in __defaults__ ])
                   
  __dict__  = property(lambda sf: { s : getattr(sf,s) for s in sf.__slots__ })

# --------------------- PUBLIC SECTION ----------------------------------------
 
  def __init__(self,**kwargs):
    "Init a dataset using keyworded parameters and default values"
    for slot, (stype, default) in self.__defaults__.items():
      setattr(self,slot,kwargs.get(slot,default))
    if not kwargs: return # Allow instance creation with defaults only ...
    name, filename, ext = self.name, self.filename, self.ext
    assert name or filename, "Dataset name or filename must be specified!"
    if not filename: filename = name if type(name) == str else name[0]
    if not name: name = filename
    if filename.find('.') == -1: filename = filename + '.' + ext
    self.name, self.filename = name, filename
    if type(self.exclude) == int: self.exclude = (self.exclude,)
    if not getattr(self,'fnames',None): self.fnames, self.num_attrs = list(), 0
    self.unknown_as = kwargs.get('unknown_as',None) # to deal with unknown values

  def __getitem__(self,key): return getattr(self,key,None)

  def __setitem__(self,key,value): return setattr(self,key,value)

  def __lshift__(self,textinfo):
    "Init a dataset using a text content"
    if textinfo: self.__init__(**self.parse_slots(textinfo))
    return self
    
  def clone(self,**kwargs):
    info, items = datainfo(), self.__dict__.items()
    [ setattr(info,key,val) for key, val in items ]
    [ setattr(info,key,val) for key, val in kwargs.items() if key in self.__dict__ ]
    return info
  
  def check_class(self,c):
    assert self.classes, "Dataset does not contain information on classes ..."
    if not callable(self.classes): # explicit pos and neg classes ...
      pcat, ncat = self.classes
      return c in pcat if type(pcat) in [list,tuple] else c == pcat
    else: # implicit pos and neg classes (as lambda function)
      try: c = float(c)
      except: pass # workaround ... TO BE FIXED ...
      return self.classes(c) # assuming floating point values ...
  
  def display(self,comment='',verbose=False):
    if comment: print(comment)
    print("Name: {}".format(self.name))
    if verbose: print("Description: {}".format(self.description))
    print("Classes: {}".format(self.classes))
    if verbose: print("Class index: {}".format(self.index))
    if verbose: print("Header: {}".format(self.header))
    print("File name: {}".format(self.filename))
    if verbose: print("File extension : {}".format(self.ext))
    if type(self.exclude) == tuple: print("Exclude: {}".format(self.exclude))
    print("Difficulty: {}".format(self.difficulty))
    if len(self.fnames) == 0: return
    sfnames = " ,".join(self.fnames)
    if len(sfnames) > 80: sfnames = sfnames[:70] + " ... etc ..."
    print("Feature names: {}".format(sfnames))
    print("Number of features: {}".format(self.num_attrs))
    smp_formatter = "Samples: {} (neg={},pos={},ratio={:4.2f})"
    print(smp_formatter.format(self.num_samples,self.num_neg,self.num_pos,self.dratio))
    
  def display_as_settings(self,swrapper=None,fwrapper=None):
    smp_formatter = "total={}, neg={}, pos={}, ratio={:4.2f}"
    if swrapper: smp_formatter = "{}({})".format(swrapper,smp_formatter)
    print(smp_formatter.format(self.num_samples,self.num_neg,self.num_pos,self.dratio))
    feat_formatter = "native={}, encoded={}"
    if fwrapper: feat_formatter = "{}({})".format(fwrapper,feat_formatter)
    print(feat_formatter.format(*self.num_attrs))

  def update(self,data,labels,fnames):
    self.fnames = fnames
    self.num_samples, self.num_attrs = data.shape
    self.num_attrs = (self.num_attrs,len(fnames))
    self.num_neg = np.where(labels == -1)[0].shape[0]
    self.num_pos = np.where(labels == +1)[0].shape[0]
    self.dratio = self.num_neg / float(self.num_pos) if self.num_pos > 0 else np.nan

# --------------------- PRIVATE SECTION ---------------------------------------

  def parse_slots(self,textinfo):
    kwargs = dict()
    void, name = textinfo[0].split()
    kwargs['name'] = eval(name.strip())
    for line in textinfo[1:]:
      slot, value = self.parse_slot(line)
      if slot in self.__slots__: kwargs[slot] = value
    return kwargs
  
  def parse_slot(self,line):
    index = line.find('=')
    slot, value = line[:index], line[index+1:]
    slot, value = strip_multiple(slot,value)
    if not slot in self.__slots__: return None, None # Not a valid slot
    stype, default = self.__defaults__[slot]
    value = conditional_eval(value,stype)
    return slot, value
    

# -----------------------------------------------------------------------------
# ------------------------ MAIN PROGRAM (for testing) -------------------------
# -----------------------------------------------------------------------------

if __name__ == '__main__':

  UCIpath = '../datasets/UCI datasets/'
  
  textdata  = [ "@dataset ('lymphography',2)",
                "  description = 'Lymphography dataset'",
                "    header   = True",
                "    classes  = 'normal', ('metastases','malign_lymph','fibrosis')",
                "    filename = 'lymphography'",
                "    ext      = 'dat'",
                "    exclude  = 0" ]

  D1 = datainfo() << textdata

  D1.display(verbose=True)

  D2 = datainfo(name=('lymphography',2), header = True,
                classes = ('normal', ('metastases','malign_lymph','fibrosis')),
                ext = 'dat')

  D2.display(verbose=True)
  
  D3 = D1.clone()
  
  D3.display(verbose=True)
  
# -----------------------------------------------------------------------------

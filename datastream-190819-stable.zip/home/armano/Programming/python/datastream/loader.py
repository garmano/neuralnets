#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb  7 10:43:23 2018

@author: giuliano
"""


import numpy as np

from datastream.datainfo import datainfo
from phidelta.statistics import Statistics

from utils.iterables   import mget, unzip2, unzip
from utils.strings     import string_split, strip_string
from utils.numbers     import array2D_to_numeric


# -----------------------------------------------------------------------------
# ------------------------ DATASET LOADER -------------------------------------
# -----------------------------------------------------------------------------

class Loader(object):

  "Handler for loading files"

# ------------------------ PUBLIC SECTION -------------------------------------

  def __init__(self, source='datasets.info', path=''):
    self.path = path
    self.source = source
    self.datasets = self.read_datasets()
    self.current_dataset = None
    self.content, self.samples = None, None

  def get(self, name, version=None):
    "Get a dataset (file information retrieved from an *.info file)"
    name = (name,version) if version else name
    print("\n^^^ Loading dataset {} ^^^\n".format(name))
    info = self.datasets.get(name,None)
    assert info, "Dataset not found looking at {} ...".format(self.source)
    data, labels, info = self.load_dataset(info)
    return data, labels, info

  def load(self, filename, **kwargs):
    "Load a dataset (file information given as kwargs)"
    kwargs['filename'] = filename
    info = datainfo(**kwargs)
    return self.load_dataset(info)
    
  def display(self, dname=None, comment='', verbose=False):
    "Display the specified (or current) dataset"
    dataset = self.datasets[dname] if dname else self.current_dataset
    dataset.display(verbose=verbose)
    
  def enum(self, comment='', difficulty=None):
    if difficulty and not type(difficulty) in (tuple,list):
      difficulty = (difficulty,)
    print()
    if comment: print(comment)
    datasets = self.datasets.values()
    counter = 0
    for k, dset in enumerate(datasets):
      if difficulty and dset.difficulty not in difficulty: continue
      print(f"{counter+1:2d}: {dset.name:20} ({k+1:02})",end='')
      print(f"   difficulty = {dset.difficulty:6}")
      # nneg, npos, dratio = mirror(dset.num_neg, dset.num_pos, dset.dratio)
      # print(f"   --   neg = {nneg}, pos = {npos}, ratio = {dratio}",end='')
      # print(f"[ num_features = {dset.num_attrs} ]")
      counter += 1
      
  def get_difficulty(self,dname):
    return self.datasets[dname].difficulty

  def select(self, difficulty=None, verbose=False, display=False):
    "Select datasets according to their difficulty"
    if not difficulty: difficulty = ('low', 'medium', 'high')
    dsets = self.datasets.values()
    selected = [ dset for dset in dsets if dset.difficulty in difficulty ]
    if display: self.multi_display(selected)
    return selected

  def multi_display(self,datasets=None,comment='',verbose=False):
    print()
    if comment: print(comment)
    if not datasets: datasets = self.datasets.values()
    counter = 0
    for dset in datasets:
      dset.display(verbose=verbose)
      counter += 1
      print()
    print("*** {} datasets have been displayed ***".format(counter))

# ------------------------ PRIVATE SECTION ------------------------------------

  def load_dataset(self,info):
    "Load a dataset (file information given as dataset object)"
    keys = ( 'filename', 'classes', 'sep', 'index', 'header', 'embedding' )
    filename, classes, sep, index, header, embedding = mget(info.__dict__,keys)
    fnames, check = None, info.check_class
    self.content = content = self.load_content(filename)
    if header: fnames, content = content[0], content[1:]
    self.samples = self.encode_samples(content, classes, sep=sep, **embedding)
    assert self.check_samples(self.samples) == list()
    data = np.array(self.samples,dtype=object)
    labels = np.array ( [ 1 if check(c) else -1 for c in data[:,index] ] )
    to_delete = [ index ] + list(info.exclude) if info.exclude else [ index ]
    to_delete = [ data.shape[1] + x if x < 0 else x for x in to_delete ]
    to_delete = sorted(to_delete)
    data = np.delete(data,to_delete,1)
    nrows, ncols = data.shape
    assert len(data) > 0, "Failure while loading file {}".format(filename)
    # update dataset information ...
    fnames = self.parse_fnames(fnames,ncols=ncols,sep=sep,index=index)
    info.update(data,labels,fnames)
    self.current_dataset = info
    return array2D_to_numeric(data,default=info.unknown_as), labels, info

  def encode_samples(self, content, classes, sep=',', **embedding):
    "Encode samples (from text to list of csv lines)"
    format = embedding.get('mode','csv') ; assert format in ('csv','inline')
    method_to_call = getattr(self,'encode_samples_' + format)
    return method_to_call(content, classes, sep=sep,**embedding)

  def encode_samples_csv(self, content, classes, sep=',', **embedding):
    "Encode samples (usually a list of csv lines)"
    # classes not required, here ...
    return [ string_split(ln,sep) for ln in content ]
  
  def encode_samples_inline(self, content, classes, sep='|', **embedding):
    "Encode inline samples (one line = one document)"
    def check_class(label,classes): # WORKAROUND ...
      if callable(classes): return 1 if classes(label) else -1
      else: return 1 if label in classes[0] else -1
    max_features = embedding.get('max_features',100)
    labels, docs = unzip2([ line.split(sep) for line in content ])
    flabels = [ check_class(label.strip(),classes) for label in labels ]
    fnames = self.get_features_from_docs(flabels,docs,max_features)
    fdata = self.get_data_from_docs(flabels,docs,fnames)
    return [ (label.strip(),) + tuple(sample) for label, sample in zip(labels,fdata) ]

  def get_features_from_docs(self,labels,docs,max_features=100):
    maxf, words = max_features, dict()
    for doc in docs:
      doc = strip_string(doc,".,;:+-'()[]{}")
      for word in doc.split():
        words.setdefault(word,0)
        words[word] += 1
    fnames = [ word for word in words.keys() ]
    if maxf == -1: return fnames # accept *all* features ...
    fnames, phi, delta = self.eval_feature_ranking(labels,docs,fnames,maxf)
    return fnames if len(fnames) < max_features else fnames[:max_features]
  
  def get_data_from_docs(self,labels,docs,fnames):
    shape = (len(labels),len(fnames))
    data = np.zeros(shape=shape,dtype=int)
    for h, doc in enumerate(docs):
      for k, fname in enumerate(fnames):
        data[h,k] = fname in doc
    return data

  def eval_feature_ranking(self,labels,docs,fnames,max_features=-1):
    from phidelta.view  import View
    data = self.get_data_from_docs(labels,docs,fnames)
    stats = Statistics(data,labels)
    phi, delta, fnames, dratio = stats.make(fnames=fnames)
    view = View(phi,delta)
    view.plot(title="Feature ranking")
    ranking = sorted(zip(fnames,phi,delta),key=lambda x: abs(x[2]),reverse=True)
    return unzip(ranking)

  def check_samples(self,samples):
    "Check sample integrity" # TO BE FIXED ...
    if not samples: return None
    counters = dict()
    for row, sample in enumerate(samples):
      slen = len(sample)
      counters.setdefault(slen,list())
      counters[slen] += [ row ]
    pcounters = list(counters.items())
    pcounters.sort()
    pcounters = pcounters[:-1] # remove the majority (perhaps all ...)
    return pcounters

  def load_content(self,filename):
    with open(self.path + filename,"rb") as infile:
      content = [ line.decode('unicode-escape').strip() for line in infile ]
    return content

  def parse_fnames(self,fnames=None,ncols=0,sep=' ',index=-1):
    if fnames:
      fnames = string_split(fnames,sep=sep)
      del fnames[index]
    else:
      fnames = [ "F" + str(k+1) for k in range(ncols) ]
    return fnames
    
  def display_samples(self,up_to=-1):
    samples = self.samples if up_to == -1 else self.samples[:up_to]
    for k, item in enumerate(samples):
      print(k," ^^^ ",item)

  def read_datasets(self):
    with open(self.path + self.source) as sourcefile:
      raw_content = [ ln.strip() for ln in sourcefile if ln.strip() != '' ]
    content = list()
    for at, line in enumerate(raw_content):
      if line.find('@dataset') == -1: continue
      print(line)
      content += [ datainfo() << self.parse_dataset(raw_content[at:]) ]
    return { dset.name : dset for dset in content }
  
  def parse_dataset(self,raw_content):
    outlist, multiline = list(), ''
    for k, line in enumerate(raw_content):
      if k > 0 and line.find('@dataset') != -1: break
      multiline += line
      mode = 'cat' if line.strip()[-1] == ',' else 'append'
      if mode == 'cat': continue
      outlist.append(multiline)
      multiline = ''
    return outlist

# -----------------------------------------------------------------------------
# ------------------------ MAIN PROGRAM (for testing) -------------------------
# -----------------------------------------------------------------------------

if __name__ == '__main__':

  dpath = '../datasets/neuralnets/'
  
  L = Loader(path=dpath)
  
  #plabs, nlabs = ('B','C','D'), ('E','H','F')
  
  #data, labels, info = L.load('flare.csv',header=True,classes=(plabs,nlabs))
  
  #data, labels, info = L.get('SPECT-full')
  #data, labels, info = L.get('arrhythmia')
  #data, labels, info = L.get('kidney-disease')
  
  #L.display()
  
  L.enum(difficulty='high')
  

# -----------------------------------------------------------------------------

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 14 15:42:22 2018

@author: armano
"""

# HANDLING MNIST DATASET (as csv)


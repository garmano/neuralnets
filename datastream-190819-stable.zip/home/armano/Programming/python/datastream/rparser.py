#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 30 15:21:27 2018

@author: armano
"""

# -----------------------------------------------------------------------------

from datastream.parser import parser

# -----------------------------------------------------------------------------

def start(date): return ('start', date)

def repeat(num_runs): return ('repeat', num_runs)
def doargs(**kwargs): return ('doargs', kwargs)
def netargs(**kwargs): return ('netargs', kwargs)
def xtrargs(**kwargs): return ('xtrargs', kwargs)

def samples(**kwargs): return ('samples', kwargs)
def features(**kwargs): return ('features', kwargs)

def cmatrix(**kwargs): return ('cmatrix', kwargs)
def performance(**kwargs): return ('performance', kwargs)
def variance(**kwargs): return ('variance', kwargs)

def end(date): return ('end', date)

# -----------------------------------------------------------------------------

class results_parser(parser):
  
  "Utility to collect information from experiment reports"
  
  __commands__ = ('start',
                  'repeat', 'doargs', 'netargs',
                  'samples', 'cmatrix',
                  'performance', 'variance',
                  'end')
  
  def __init__(self,logfile='log_results.txt',path=''):
    "Init the results parser"
    super().__init__(logfile,path)
    self.load() # automatically loads the commands ...

  def load(self,comment="Loading batch results file"):
    "Load results from file"
    return super().load(comment)
      
  def parse(self):
    "Parse result file content"
    experiments = dict()
    for command in self.get_commands():
      if '@dataset' in command:
        dname, annotations = self.get_information_on_runs(command)
        experiments[dname] = annotations
    return experiments

  def get_information_on_runs(self,command):
    "Get dataset name and information about runs"
    header, *annotations = command.split('--')
    __, dname = header.split() # remove '@dataset' from the header ...
    return eval(dname), self.parse_annotations(annotations)

  def parse_annotations(self,annotations):
    "Get information about runs"
    outlist = list()
    for k, item in enumerate(annotations):
      if item.find('repeat') > -1: # starts a new experiment report ...
        outlist += [ self.parse_annotation(annotations,at=k) ]
    return outlist
        
  def parse_annotation(self,annotations,at=0):
    outlist = list()
    for k, cmd in enumerate(annotations[at:]):
      if k > 0 and cmd.find('repeat') > -1: break
      outlist += [ eval(cmd) ]
    return outlist

# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  from utils.date import current_date
  
  epath = "../experiment summaries/logfiles/runs {}/".format(current_date(format='tiny'))
  
  p = results_parser(logfile='logger 18-11-12 (1710).log', path=epath)
  
  commands = p.parse()
  

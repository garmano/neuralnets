#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 16 15:59:41 2018

@author: armano
"""

-------------------

  def make_transducers(self,shape,layers):
    "Build the list of transducers"
    transducers = list()
    for layer, next_layer in zip(:
      in_units, out_units = layers[k].num_units, layers[k+1].num_units
      transducers.append(Transducer(in_units,out_units,level=k))
    return transducers

  def link_layers2transducers(self,layers,transducers):
    for k, layer in enumerate(layers[1:]):
      layer.link(transducers[k-1])

class outputLayer(Layer):
  
  def __init__(self,*args,**kwargs):
    super().__init__(*args,**kwargs)
    self.error = None
  
  def propagate_forward(self):
    raise Exception("Cannot propagate forward from output layer!")
  
  def propagate_backward(self):
    pass
  
class inputLayer(Layer):
  
  def __init__(self):
    pass
  
  def propagate_forward(self):
    pass

  def propagate_backward(self):
    raise Exception("Cannot propagate backward from input layer!")
    
    
# ------------------------------ DWEIGHTS -------------------------------------

class DWeights(object):
  
  def __init__(self):
    pass
  
  def as_array(self):
    return np.atleast_2d(self.units)
  
  
  
from phidelta.features import new_feature

  def new_features(self,fnames,data,verbose=False):
    nrows, ncols = data.shape
    return [ new_feature(fnames[k],'auto',data[:,k],verbose=verbose) for k in range(ncols) ]
    
  def train_OLD(self, data, labels, indexes=None, comment='', verbose=True, ratio=1.):
    if indexes: data, labels = data[indexes], labels[indexes]
    if comment: print("\n {}\n".format(comment))
    print("Training network with shape",self.shape)
    self.error, self.errors = -1., list()
    for i in range(self.num_epochs):
      printf("*",end='\n' if (i+1) % 50 == 0 else '')
      if verbose and len(self.errors) > 8: self.viewErrors(i)
      for k, sample in enumerate(data):
        self.propagate_forward(data[k,:])
        self.error = self.propagate_backward(labels[k])
        self.errors += [ (i,k,self.error) ]
    print()

----------------

  def reset_transducers(self):
    "Reset list of weights"
    [ transducer.reset() for transducer in self.transducers ]

  def update_transducers(self,deltas):
    "Update list of weights"
    [ transducer.update(deltas) for transducer in self.transducers ]

----------------

  __parameters__ = ('learning_rate','momentum')
  
  def __lshift__(self,kwargs):
    "Parameter setting"
    for key, val in kwargs.items():
      if key not in self.__parameters__: continue
      setattr(self,key,val)

----------------

  def eval_layer_errors(self,target):
    "Compute error on output layer"
    delta = list() # Output layer error
    error = target - self.output_layer.outputs
    delta = error * dsigmoid(self.output_layer)
    delta.append(delta)
    for i in range(self.num_layers-2,0,-1): # Hidden layers errors
      delta = np.dot(delta[0],self.weights[i].T) * dsigmoid(self.layers[i])
      delta.insert(0,delta)
    return delta
    
  def transduce(self, data,up_to=1, output_as='array'):
    outputs = list()
    for sample in data:
      self.propagate_forward(sample)
      outputs += [ np.copy(self.layers[up_to]) ]
    return np.array(outputs) if output_as == 'array' else outputs

----------------

    print("\nEEEEHHHH error",error)
    print("         outputs",outputs)
    print("         inputs",self.collector.inputs)

----------------

  #import numpy as np

#  def test_majority_class(nn,labels,ratio):
#    majority_class, chance = nn.set_majority_class(ratio)
#    num_neg, num_pos = 0, 0
#    for label in labels:
#      if not nn.check_majority_class(label,majority_class,chance): continue
#      if label == -1: num_neg += 1
#      else: num_pos += 1
#    return num_neg, num_pos
#
#  labels = np.random.randint(0,high=2,size=1000)
#  
#  for k in range(1000):
#    if labels[k] == 0: labels[k] = -1
#
#  nneg, npos = test_majority_class(nn,labels,ratio=1.)
#
#  print("EEEHHHH",nneg,npos)

----------------

  def set_logfile(dataset,shape,mode,date=None,path=''):
    if not date: date = get_current_date(remove='ss')
    formatter = "{}{}-{}-shape(__, {})-{}.log"
    return formatter.format(path,date,dataset,str(shape)[1:-1],mode)

----------------

  def train(self, data, labels, indexes=None, comment='', verbose=True, balanced=True):
    if indexes: data, labels = data[indexes], labels[indexes]
    if comment: print("\n {}\n".format(comment))
    print("Training network with shape",self.shape)
    self.errors, self.error = list(), -1.
    source = dataSource(data,labels,indexes=indexes,balanced=balanced)



   for j in range(self.num_epochs):
      printf("*",end='\n' if (j+1) % 100 == 0 else '')
      if verbose and len(self.errors) > 8: self.viewErrors(j)
      for k in range(num_samples):
        if toggle % 2: # get a positive sample
          pos_count, sample = self.next_sample(pos_data,num_pos,pos_count)
        else: # get a negative sample
          neg_count, sample = self.next_sample(neg_data,num_neg,neg_count)
        
          
        negctr += 1 if labels[k] == -1 else 0
        posctr += 1 if labels[k] == +1 else 0
        self.propagate_forward(data[k,:])
        self.error = self.propagate_backward(labels[k])
        self.errors += [ (i,k,self.error) ]
    print("\n+++ Processed {} neg samples and {} pos samples".format(negctr,posctr))
    
    
    class dataSource(object):
  
  "Data handler for training ML algorithms"
  
  def __init__(self, data, labels, indexes=None, balanced=True):
    self.data   = data   if not indexes else data[indexes]
    self.labels = labels if not indexes else labels[indexes]
    self.num_samples, self.num_attrs = data.shape
    self.neg_count, self.pos_count = 0, 0
    self.neg_data, self.pos_data = self.data[labels==-1], self.data[labels==+1]
    self.num_neg, self.num_pos = len(self.neg_data), len(self.pos_data)
 
  def __iter__(self):
    if not self.balanced: return iter(zip(self.data,self.labels))
    outdata = list()
    majority_class = self.check_equality(self.num_neg,self.num_pos)
    
    if maj_class == 0 or not self.balanced: return iter(zip(self.data,self.labels))
    outdata = list()
    maj_data, min_data = self.neg_data, self.pos_data
    if majority_class == +1: maj_data, min_data = min_data, maj_data
    for sample, label in zip()
      
    
  def check_equality(self,a,b):
    return 0 if a == b else -1 if a > b else +1



----------------

  def settings(self,**kwargs):
    "Set the network relevant parameters"
    [ setattr(self,k,v) for k,v in kwargs.items() if k in self.__settings__ ]
    return self
   
----------------

#  def update_shape(self,fnames):
#    "Update the shape"
#    self.shape[0] = len(fnames)

----------------

# -----------------------------------------------------------------------------

class activate_strategy(object):
  
  __available_strategies__ = ('backpropagation', 'progressive')
  
  @staticmethod
  def __getitem__(strategy):
    assert(strategy in __available_strategies__)
    return 

link2strategy(strategy,*args,**kwargs):

----------------

@singleton
class trainingStrategies(registry):
  
  "Generic repository for training strategies"
  
  def __init__(self): super().__init__()
    
training_strategies = trainingStrategies() # singleton for training strategies

----------------

@singleton
class training_strategies(registry): # also ABC may be used ...
  
  "Repository for training strategies"
  
  def __init__(self): super().__init__()
  
  def __lshift__(self,strategies):
    if type(strategies) not in (tuple,list): strategies = (strategies,)
    for s in strategies: self[s] = str2class(s,module=__name__)

training_strategies() << ('backpropagation','progressive')

----------------

from utils.patterns    import registry

class training_store(registry):
  
  repository = dict()
  
  @classmethod
  def __lshift__(cls,subclasses):
    if type(subclasses) not in (tuple,list):subclasses = (subclasses,)
    for subclass in subclasses:
      cls.repository[subclass.__name__] = subclass
  
  @classmethod
  def display(cls,comment=''):
    if not comment: comment = "Displaying available training strategies"
    print(comment)
    print(list(cls.repository.keys()))

----------------

  def get_strategy(self,strategy):
    strategy_class = training_store()[strategy]
    return strategy_class(self) # link the strategy to self ...    

----------------

  def display(self,comment=''):
    if not comment:comment="Profiler for multilayer perceptrons"
    data, labels = mirror(self.data, self.labels)
    print("Data   shape is {}".format(tuple() if data is None else data.shape))
    print("Labels shape is {}".format(tuple() if labels is None else labels.shape))
    print("MLP network  is {}".format(self.mlp))

----------------

  def train_and_test(self,data,labels,verbose=False,**kwargs):
    keys = 'train_percent','shuffle', 'ratio'
    train_percent,shuffle, ratio = multiple_get(kwargs,keys, (50, False, 1.))
    num_samples, __ = data.shape
    trn_set, tst_set = split_data(num_samples,train_percent,shuffle)
    classifier = self.train(data[trn_set],labels[trn_set],verbose=verbose)
    cm = classifier.test(data[tst_set],labels[tst_set],verbose=verbose)
    return classifier, cm

----------------

  def train(self,data,labels,**kwargs):
    return self.learner.train(data,labels,**kwargs)

  def test(self,data,labels,classifier,**kwargs):
    return classifier.test(data,labels,**kwargs)

----------------

    # Checking whether the error is decreasing ...
    delta_error = mirror(self.__delta_error__)
    last_errors = [ np.mean(self.buffer[k-25:k]) for k in self.__check_points__ ]
    for prev_error, error in shift_and_zip(last_errors):
      if prev_error > error: continue
      return False

----------------

  def set_inputs(self,num_inputs,bias):
    "Set transducer inputs (taking bias into account)"
    num_inputs += len(bias) # adding extra inputs for +1. and/or -1. bias ...
    inputs = np.zeros(num_inputs)
    for k, b in enumerate(bias): inputs[-(k+1)] = b
    return num_inputs, inputs
    
----------------

 def __init__(self,num_inputs,num_outputs,bias=(-1.,+1.),level=0,**kwargs):
    "Initialize the transducer"
    self.level = level # just for debugging ...
    self.bias = bias if type(bias) in (tuple,list) else (bias,)
    self.num_inputs, self.inputs = self.set_inputs(num_inputs,bias)        
    self.num_outputs, self.outputs = self.set_outputs(num_outputs)
    self.weights = self.set_weights()
    self.deltaw  = np.zeros(self.shape)
    self.reset_weights()
    self(**kwargs)

----------------

  def set_inputs(self,num_inputs,bias):
    "Set transducer inputs (taking bias into account)"
    return num_inputs, np.zeros(num_inputs)
    
  def set_outputs(self,num_outputs):
    "Set transducer outputs"
    return num_outputs, np.zeros(num_outputs)

----------------

class performance_logger(object):
  
  all    = property(lambda self: [ n+p for n, p in zip(self.neg,self.pos) ])
  spec   = property(lambda self: [ self.]) 
  
  __pslots__ = ('TN', 'TP', 'FN', 'FP')
  
  def __init__(self):
    "Init the logger"
    self.TN, self.FP, self.FN, self.TP = list(), list(), list(), list()
    self.neg, self.pos = list(), list()
    self.cm_mean = cmatrix()
    self.num_insertions= 0
    
  def reset(self):
    "Reset the logger"
    self.__init__()
    
  def __lshift__(self,**kwargs):
    "Insert values into the logger"
    TN, FP, FN, TP = mget(kwargs,self.__pslots__)
    self.TN += TN ; self.FP += FP
    self.FN += FN ; self.TP += TP
    self.num_insertions += 1

  def average(self):
    "Evaluate the average of all measures"
    if self.num_insertions == 0: return 0., 0., 0., 0.
    cm_array = np.ndarray([ self.TN, self.FP, self.FN, self.TP])
    mean = np.mean(cm_array,axis=1) # ordering: TN, FP, FN, TP
    self.cm_mean['all'] = tuple(mean)
    return mean
  
  def variance(self):
    "Evaluate the variance of all measures"
    if self.num_insertions == 0: return 0., 0., 0., 0.
    cm_array = np.ndarray([ self.TN, self.FP, self.FN, self.TP])
    var = np.var(cm_array,axis=1) # ordering: TN, FP, FN, TP
    #self.cm_var['all'] = tuple(var)
    return var
 
# -----------------------------------------------------------------------------

----------------

  def specificity(self):
    "Evaluate the average specificity over all measures (with variance)"
    if self.num_insertions == 0: return np.array(tuple(0., 0., 0., 0.))
    spec_list = np.array([ cm.spec for cm in self.cm_list ])
    return np.mean(spec_list), np.var(spec_list)

  def sensitivity(self):
    "Evaluate the average sensitivity over all measures (with variance)"
    if self.num_insertions == 0: return np.array(tuple(0., 0., 0., 0.))
    sens_list = np.array([ cm.sens for cm in self.cm_list ])
    return np.mean(sens_list), np.var(sens_list)
  
  def accuracy(self):
    "Evaluate the average accuracy over all measures (with variance)"
    if self.num_insertions == 0: return np.array(tuple(0., 0., 0., 0.))
    acc_list = np.array([ cm.acc for cm in self.cm_list ])
    return np.mean(acc_list), np.var(acc_list)
  
  def phi(self):
    "Evaluate the average phi over all measures (with variance)"
    if self.num_insertions == 0: return np.array(tuple(0., 0., 0., 0.))
    phi_list = np.array([ cm.phi for cm in self.cm_list ])
    return np.mean(spec_list), np.var(spec_list)

  def delta(self):
    "Evaluate the average delta over all measures (with variance)"
    if self.num_insertions == 0: return np.array(tuple(0., 0., 0., 0.))
    spec_list = np.array([ cm.spec for cm in self.cm_list ])
    return np.mean(spec_list), np.var(spec_list)
  
# ----------------
  
  @logfile "neuralnets-{}".format(get_current_date(remove='ss'))

  dentro parse di batch_parser
  
        if '@logfile' in command:
        format_ndx = command.find('"')
        logfile = command[format_ndx:] # skip '@logfile ' ...

# ----------------
  
    def get_relevant_information(self,cmd_dict):
    "Get relevant information from a command list"
    doargs, netargs = mget(cmd_dict,('doargs','netargs'))
    mode, shape, strategy = mget(doargs,('mode','shape','strategy'))
    LRate, momentum, num_epochs = mget(netargs,('learning_rate','momentum','num_epochs'))
    cmatrix, performance, variance = mget(cmd_dict,('cmatrix', 'performance', 'variance'))
    return mode, shape, strategy, LRate, momentum, num_epochs, cmatrix, performance, variance

# ----------------
  
    __relops__ = { '<': oper.lt, '>': oper.gt, '==': oper.eq }
  
  def __init__(self, **kwargs):
    "Init the constraint checker"
    for k, val in kwargs.items():
      val == str(val) # make val a string to facilitate further processing ...
      if k not in self.__slots__: continue
      if "lambda" not in val: val = "lambda s: s == {}".format(val)
      
      if val[0] in ('<','>','='): # see __relops__ above
        op, val = val.split()
        setattr(self,k,lambda v: self.__relops__[op](len(v),val) )
      else:
        setattr(self,k,lambda v: v == val)

# ----------------
  
    def prune_OLD(self,data,labels,layer_ndx=-1,verbose=0,**kwargs):
    "Prune a layer according to a phidelta heuristics"
    min_delta, min_percent = mirror(self.__min_delta__, self.__min_percent__)
    phi, delta, *more = self.make_stats(data,labels,up_to=layer_ndx,verbose=verbose)
    constraint = abs(delta) >= min_delta
    if np.count_nonzero(constraint) < self.__min_units__: return constraint.size
    return self.layers[layer_ndx].prune(constraint)


# ----------------
    
    def errors_OLD(self,minmax=(0.1,1.0)):
    "Set a new error profile (linear decrement)"
    min_error, max_error = minmax
    derror = float(max_error - min_error) / len(self.ishape)
    self.errors = list()
    for k, x in enumerate(self.ishape): # linear decrement of the error
      self.errors += [ max_error - k * derror ]

# ----------------
      
def unzip3(values):
  "Unzip a list of triples (accepts also arrays)"
  to_array = type(values) == np.ndarray
  X = [ x for x, y, z in values ]
  Y = [ y for x, y, z in values ]
  Z = [ z for x, y, z in values ]
  return (np.array(X), np.array(Y), np.array(Z)) if to_array else (X, Y, Z)

# ----------------

  #from itertools import product

#  def phidelta_std(spec,sens): return -spec + sens, spec + sens - 1
  
#  Spec   = np.linspace(0.,+1.,50+1)
#  Sens   = np.linspace(0.,+1.,50+1)
#
#  Delta = np.linspace(0.,+1.,100+1)

  # Verifica nel caso in cui delta e delta_0 coincidono

#  for k, delta in enumerate(Delta):
#    solutions = G(0.,delta)
#    formatter = "delta = {:4.4f} --> {:+4.4f}, {:+4.4f}, {:+4.4f}"
#    print(formatter.format(delta,*solutions))
  
  # Verifica nel caso generale (<phi,delta> qualunque all'interno del rombo)

#  for k, (spec,sens) in enumerate(product(Spec,Sens)):
#    phi, delta = phidelta_std(spec,sens)
#    solutions = G(phi,delta)
#    formatter = "phi = {:+4.4f} delta = {:+4.4f} --> {:+4.4f}, {:+4.4f}, {:+4.4f}"
#    print(formatter.format(phi,delta,*solutions),end=' ')
#    print(check_solutions(phi,delta,solutions))

#  costFun = costFunction(make_sigmoid())

#  X,Y = unzip2([ (spec,sens) for (spec,sens) in product(Spec,Sens) ])
#  X, Y = np.array(X), np.array(Y)
#  Phi,Delta = phidelta_std(X,Y)
#  Z = np.array([ costFun(phi,delta) for phi, delta in zip(Phi,Delta) ])
 
# ----------------
  
    def parse_OLD(self):
    "Parse the batch file content"
    constraints, experiments = dict(), dict()
    for command in self.get_commands():
      if '@dataset' in command:
        if "--skip" in command: continue
        dname = self.get_dataset_name(command)
        expected = self.get_dataset_constraints(command)
        annotations = self.get_dataset_annotations(command)
        constraints[dname], experiments[dname] = expected, annotations
    return constraints, experiments
  

# ----------------
    
    def check_class(self,c):
    assert self.classes, "Dataset does not contain information on classes ..."
    if not callable(self.classes): # explicit pos and neg classes ...
      pcat, ncat = self.classes
      return c in pcat if type(pcat) in [list,tuple] else c == pcat
    else: # implicit pos and neg classes (as lambda function)
      try: fval = float(c)
      except: fval = 0. # workaround ... (the dataset may be corrupted)
      return self.classes(fval) # assuming floating point values ...
  

# ----------------

  def make_stats_SAVE(self,data,labels,up_to=-1,verbose=0):
    outputs = self.mlp.transduce(data,up_to=up_to)
    return Statistics(outputs,labels).make(verbose=verbose)
    
# ----------------
    
  def make_all_stats_SAVE(self,data,labels,verbose=0):
    statistics, outcomes = list(), list()
    outputs = data 
    for k, layer in enumerate(self.mlp.layers):
      stats = Statistics(outputs,labels)
      outcomes += [ stats.make(verbose=verbose) ]
      statistics += [ stats ]
      if k < self.mlp.num_layers - 1:
        outputs = self.mlp.transduce(data,up_to=k+1)
    return statistics, outcomes

# ----------------
# ----------------
# ----------------
# ----------------
# ----------------
# ----------------
# ----------------
# ----------------
# ----------------
# ----------------
# ----------------








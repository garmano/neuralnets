#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov  8 16:14:02 2018

@author: armano
"""

# -----------------------------------------------------------------------------

from datastream.loader    import Loader
from datastream.rparser   import results_parser

from utils.patterns       import constraint as constraint_builder
from utils.iterables      import mget, flatten

# -----------------------------------------------------------------------------

class report_info(object):
  
  "Embeds relevant information taken from a report"
  
  __slots__ = ('mode', 'strategy', 'shape', 
               'learning_rate', 'momentum', 'num_epochs',
               'cmatrix', 'performance', 'variance')
  
  __cmatrix__ = ('TN', 'FP', 'FN', 'TP')
  __performance__ = ('spec', 'sens', 'acc', 'phi', 'delta' )
  __variance__ = tuple([ 'v' + item for item in __performance__ ])
  
  def __init__(self):
    [ setattr(self,slot,None) for slot in self.__slots__ ]
    
  def __lshift__(self,kwargs):
    [ setattr(self,k,val) for k, val in kwargs.items() if k in self.__slots__ ]
    return self
  
  @classmethod
  def slots(cls):
    outlist = [ 'dataset', 'difficulty' ]
    for slot in cls.__slots__:
      if   slot == 'cmatrix': outlist +=  cls.__cmatrix__
      elif slot == 'performance': outlist += cls.__performance__
      elif slot == 'variance': outlist += cls.__variance__
      else: outlist += [ slot ]
    return "; ".join(outlist)
  
  def __str__(self):
    cm_slots = ('TN','FP','FN','TP')
    pf_slots = ('spec','sens','acc','phi','delta')
    outdict = { k : getattr(self,k) for k in self.__slots__ }
    outdict['shape'] = str(outdict['shape']) # to prevent shape flattening ...
    outdict['cmatrix'] = [ outdict['cmatrix'][k] for k in cm_slots ]
    outdict['performance'] = [ outdict['performance'][k] for k in pf_slots ]
    outdict['variance'] = [ outdict['variance'][k] for k in pf_slots ]
    outlist = [ outdict[k] for k in self.__slots__ ]
    outstring = "; ".join([ str(x) for x in flatten(outlist)])
    return outstring

# -----------------------------------------------------------------------------

class batch_reporter(results_parser):
  
  "Utility for generating a CSV file containing the exp results of a batch run"
  
  def __init__(self,logfile,path=''):
    "Init the reporter"
    super().__init__(logfile,path)
    self.csvfile, self.csvpath = None, None
    self.commands = self.parse()
    self.checker = constraint_builder() # no constraints by default
    
  def constraints(self,**kwargs):
    self.checker = constraint_builder(**kwargs)
    return self
    
  def __iter__(self):
    return iter(self.commands.items())

  def save(self, csvfile='report.csv', csvpath='',comment=''):
    "Save information to a csv file"
    self.csvfile, self.csvpath = csvfile, csvpath
    dpath  = '../datasets/neuralnets/'
    L = Loader(path=dpath)
    with open ( self.csvpath + csvfile, 'w+') as outfile:
      if comment: outfile.write(comment + '\n')
      outfile.write(report_info.slots() + '\n')
      for dname, commands in self.commands.items():
        difficulty = L.get_difficulty(dname)
        for cmd in commands:
          if not self.checker.recursive_check(**dict(cmd)): continue
          outcomes = str(self.get_relevant_information(dict(cmd)))
          outfile.write(f"{dname}; {difficulty}; {outcomes}\n")
    return
          
  def get_relevant_information(self,cmd_dict):
    "Get relevant information from a command list"
    doargs, netargs = mget(cmd_dict,('doargs','netargs'))
    return report_info() << doargs << netargs << cmd_dict

# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  import os
  
  def test_shape(run):
    if not run.get('shape'): return '' # temporary ...
    return '1HL' if run['shape']((10,1)) else 'nHL'
  
  # cdate = current_date(format='tiny')

  cdate = "190708"
  
  lpath = "../experiment summaries/logfiles/runs {}/".format(cdate)
  epath = "../experiment summaries/csvfiles/runs {}/".format(cdate)

  if not os.path.exists(epath): os.makedirs(epath)

  #r = batch_reporter(logfile='logger 18-11-12 (1710).log',path=lpath)
  r = batch_reporter(logfile='logger-19-07-08.log',path=lpath)
  
#  run_1HL   = settings(strategy='backprop', shape=lambda s: len(s) == 2)
#  run_nHL   = settings(strategy='backprop', shape=lambda s: len(s) > 2)
#  run_pro   = settings(strategy='progressive')
  
  #all_runs = (run_1HL, run_nHL, run_pro)
  #all_runs = (run_1HL, )
  
#  for _run in all_runs:
#    r.constraints(**_run)
#    mode, strategy = mget(_run,('mode','strategy'),defaults=('',''))
#    shape = test_shape(_run)
#    r.save("exp-results-" + "-".join([mode,strategy,shape]) + ".csv",epath)
  
  r.save("runnerlog-19-07-08.csv",epath)
  
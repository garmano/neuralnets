# -------------------- EXPERIMENTS --------------------------------------------

# -*- coding: utf-8 -*-
"""
Created on Tue Oct 30 14:53:00 2018

@author: armano
"""

# -----------------------------------------------------------------------------

from datastream.cparser    import cmd_parser
from datastream.logging    import logger

from neuralnets.runner     import Profiler

from experiments           import Experiment

from utils.date            import get_current_date
from utils.params          import mirror
from utils.printing        import stream

# -----------------------------------------------------------------------------

class batchProfiler(cmd_parser):
  
  def __init__(self, batchfile=None, path='', logging="multiple"):
    assert logging in ('single', 'multiple')
    super().__init__(batchfile,path)
    self.batchfile, self.path, self.logging = batchfile, path, logging
    self.commands = self.parse() # parse commands from batch file

  def execute(self,dpath=''):
    logname = 'logger' if self.logging == 'single' else None
    logfile = logger.set_logfile(name=logname) if logname else None 
    for cmd in self.commands:
      if not logname: logfile = logger.set_logfile(name=cmd.dname)
      eprofiler = Profiler(name=cmd.dname,path=dpath,logger=logfile)
      experiment = Experiment(dataset=cmd.dname,path=dpath)
      dname, difficulty = mirror(cmd.dname,experiment.info.difficulty)
      formatter = "@dataset '{}'    --difficulty '{}'\n"
      stream(logfile) << print(formatter.format(dname,difficulty))
      for crun in cmd.runs:
        kwargs = dict(crun.doargs,**crun.netargs)
        eprofiler.execute(experiment, crun.repeat, **kwargs)

# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  from datastream.about import about
  
  about # to avoid warnings ...
  
  dpath = '../datasets/neuralnets/'
  
  bpath, epath, lpath = logger.get_paths()

  cdate = get_current_date(remove=tuple(),strip=tuple())
  
  print("\nRUNNING BATCH FILE (date is {})".format(cdate))
  
  shuffle = True
  logging = 'multiple' # 'single' or 'multiple'
  
  # batchfile = "scientific-reports.batch"
  batchfile = "scientific-reports-trials.batch" # TEMPORARY ...
  
  bprofiler = batchProfiler(batchfile=batchfile,path=bpath,logging=logging)

  bprofiler.execute(dpath=dpath)

# ----------------------------------------------------------------------

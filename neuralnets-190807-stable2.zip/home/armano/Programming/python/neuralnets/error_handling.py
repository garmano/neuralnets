#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 26 13:01:53 2018

@author: armano
"""

# -----------------------------------------------------------------------------

import numpy as np

from utils.params     import mirror

# -----------------------------------------------------------------------------

class error_logger(object):
  
  "Tool for logging and handling errors"
  
  __max_buffer__   = 200
  __delta_error__  = 0.1
  __check_points__ = list(range(25,200+1,25))
  __min_epochs__   = 20
  
  __settings__    = ('max_buffer','delta_error','check_points')

  num_samples     = property(lambda self: self.data[:,0].size)
  num_attrs       = property(lambda self: self.data[0].size)
  num_epochs      = property(lambda self: self.error_grid[:,0].size)
  
  last_error      = property(lambda self: self.buffer[0])
  
  def __init__(self, data, labels, num_epochs, **kwargs):
    "Init the error logger"
    self.max_buffer   = kwargs.get('max_buffer',self.__max_buffer__)
    self.delta_error  = kwargs.get('delta_error',self.__delta_error__)
    self.check_points = kwargs.get('check_points',self.__check_points__)
    self.min_epochs   = kwargs.get('min_epochs',self.__min_epochs__)
    num_samples, __   = data.shape
    self.grid         = np.zeros(shape=(num_epochs,num_samples)) - 1
    self.buffer       = - np.ones(self.__max_buffer__)
    self.data         = data
    self.labels       = labels
    self.num_epoch    = 0
    
  def __call__(self,**kwargs):
    "Set parameters of the error logger"
    [ setattr(self,k,v) for k, v in kwargs.items() if k in self.__settings__]

  def update(self,num_epoch,num_sample,error):
    "Update the error logger"
    self.buffer = np.roll(self.buffer,1) ; self.buffer[0] = error
    self.grid[num_epoch,num_sample] = error
    self.num_epoch = num_epoch
    
  def check(self):
    "Check for stop-iteration condition" # TO BE MODIFIED !!!
    if self.num_epoch < self.min_epochs: return False
    last_errors = [ np.mean(self.buffer[k-25:k]) for k in self.check_points ]
    min_error, max_error = np.min(last_errors), np.max(last_errors)
    if min_error < 0.: return False # WORKAROUND ...
    if self.delta_error is None: return False # WORKAROUND ...
    return max_error - min_error < self.delta_error
    
  def display(self,up_to=None):
    "Display the content of the error logger"
    buffer, check_points = mirror(self.buffer,self.check_points)
    if up_to:
      formatter = "Displaying last {} errors ... (delta_error = {})"
      print(formatter.format(up_to,self.delta_error))
      [ print("{:4.6f}".format(error),end = ", ") for error in buffer[:up_to] ]
      print()
    last_errors  = [ "{:4.4f}".format(np.mean(buffer[:k])) for k in check_points ]
    last_errors  = str(last_errors).replace("'","")
    print("Mean errors over the last {} steps are {}".format(check_points,last_errors))
  
  def displayGrid(self,num_epoch=0):
    "Display the error grid"
    print(str(self.grid[num_epoch]))

# -----------------------------------------------------------------------------

if __name__ == "__main__":
  
  data   = np.random.random(size=(120,10))
  labels = np.random.randint(0,2,size=120) * 2 - 1.
  
  eh = error_logger(data,labels,num_epochs=100)
  
  for num_epoch in range(100):
    for num_sample in range(eh.num_samples):
      if np.random.random() > 0.35: # random selection over samples ...
        eh.update(num_epoch,num_sample,np.random.random() / 10.)

  eh.display()

# -----------------------------------------------------------------------------

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun 16 22:05:24 2018

@author: armano
"""

# -----------------------------------------------------------------------------

import random

import time

# -----------------------------------------------------------------------------

from termcolor            import colored

from utils.numbers        import normalize as normalize_data
from utils.printing       import stream
from utils.params         import mirror

#from utils.graphics       import backendHandler

from mining.constraints   import mirror_data, index_data
from mining.constraints   import split_data, make_paired_fold

from images.image_handler import combine_images

from phidelta.statistics  import Statistics
from phidelta.view        import View
from phidelta.features    import encode as encode_features

from datastream.loader    import Loader

from neuralnets.results   import manifoldResultsHandler

# -----------------------------------------------------------------------------

class Experiment(object):
  
  "Utility class for running an experiment"
  
  name     = property(lambda self: self.info.name if self.info else 'unknown') 

  def __init__(self, dataset, path='', learner=None):
    "Init the experiment"
    self.dataset, self.path = dataset, path
    self.loader = Loader(path=path)
    self.data, self.labels, self.info = self.loader.get(dataset)
    self.fnames, self.fdata = self.encode(self.data,self.labels)
    self.flabels = self.labels # TEMPORARY ...
    self.num_samples, self.num_attrs = self.fdata.shape
    self.learner, self.classifier = learner, None
    self.train_ndx, self.test_ndx = None, None
    self.folds = list()
    self.info.display()
    
  def link_to(self,learner):
    "Link to the learner" # not used ...
    self.learner = learner

  def save_views(self,views,stream,fold,combo=False):
    "Save the views to file"
    fnames = list()
    if stream[-4:] == '.log': stream = stream[:-4] # WORKAROUND ...
    cname = stream + fold
    for k, view in enumerate(views):
      fname = cname + "-layer({}).png".format(k)
      if not combo: print("Saving figure",fname)
      view.figure.savefig(fname)
      fnames += [ fname ]
    if combo: # (many figures --> one file)
      cname += '.png'
      print("Saving figures (combo mode)",cname)
      combine_images(cname,fnames,remove_sources=True)
    return views
  
  def delete_views(self,views=None):
    "Delete views (used in combination with 'save_views')"
    print("*** Now deleting all views ***")
    for view in views: view.close()
    # matplotlib.pyplot.close('all')
    # NOT WORKING YET ...

  def encode(self,data,labels,normalize=True,flatten=True):
    "Encode data (and labels)"
    encode_features('nominal','as_one_hot') # preferred encoding for neural nets
    stats = Statistics(data,labels)
    self.fnames, self.fdata = stats.encode_data(data=data,info=self.info,flatten=flatten)
    #print(self.fdata)
    self.info.update(data,labels,self.fnames)
    #self.info.display()
    #self.update_shape(fnames)
    if normalize: self.fdata = normalize_data(self.fdata)
    return self.fnames, self.fdata
  
  def train_and_test(self,data,labels,train_percent=50,shuffle=True,**kwargs):
    "Train and test ..."
    num_samples, num_attrs = data.shape
    if train_percent == 100: trn_ndx, tst_ndx = mirror_data(num_samples,shuffle,2)
    else: trn_ndx, tst_ndx = split_data(num_samples,train_percent,shuffle)
    self.train_ndx, self.test_ndx = trn_ndx, tst_ndx
    trn_data, trn_labels = index_data(data,labels,indexing=trn_ndx)
    tst_data, tst_labels = index_data(data,labels,indexing=tst_ndx)
    self.classifier = self.learner.train(trn_data,trn_labels,**kwargs)
    cm = self.classifier.test(tst_data,tst_labels,**kwargs)
    stats, outcomes = self.classifier.make_all_stats(tst_data,tst_labels,**kwargs)
    return (stats,outcomes,cm)
  
  def test_training_set(self, display=True, verbose=0, **kwargs):
    "Make a test on the training set (the classifier has already been trained)"
    data, labels = self.fdata[self.train_ndx], self.flabels[self.train_ndx]
    cm = self.classifier.test(data,labels,verbose=verbose)
    stats, outcomes = self.classifier.make_all_stats(data,labels,**kwargs)
    if display: self.display_statistics(stats,outcomes,verbose=verbose)      
    return (stats,outcomes,cm)

  def keyfold_test(self,data,labels,num_folds=10,shuffle=True,**kwargs):
    "Make keyfold test"
    num_samples, num_attrs = data.shape
    self.make_kfolds(num_samples,num_folds,shuffle)
    mresults = manifoldResultsHandler()
    for step, fold in enumerate(self.folds):
      mresults << self.keyfold_step(data,labels,step,shuffle,**kwargs)
    return mresults

  def keyfold_step(self,data,labels,step=0,shuffle=True,**kwargs):
    "Make one step of a keyfold test"
    print("\n^^^ Testing fold {} of {} ^^^\n".format(step+1,self.name))
    num_samples, num_attrs = data.shape
    fold  = self.folds[step] # test set
    pfold = make_paired_fold(num_samples,fold,shuffle=shuffle) # training set
    self.learner.reset_errors() # to start over with a new error logger ...
    self.classifier = self.learner.train(data[pfold],labels[pfold],**kwargs)
    cm = self.classifier.test(data[fold],labels[fold],**kwargs)
    stats, outcomes = self.classifier.make_all_stats(data[fold],labels[fold],**kwargs)
    return (stats,outcomes,cm)

  def make_kfolds(self,num_samples,num_folds=10,shuffle=True):
    "Make folds (for kfold cross validation"
    indexes = list(range(num_samples))
    if shuffle: random.shuffle(indexes)
    if num_folds == 1: return indexes # return value for num_folds == 1
    ifolds = self.find_cutpoints(num_samples,num_folds)
    folds = [ list() for x in ifolds ]
    level = 0
    for k, index in enumerate(indexes):
      if k == ifolds[level]: level += 1
      folds[level] += [ index ]
    self.folds = folds # folds are embedded in the experiment ...
        
  def find_cutpoints(self,num_samples,num_folds):
    "Find cut-points (for kfold cross validation)"
    samples_per_fold = int(num_samples/num_folds)
    indexes = [ samples_per_fold ] * num_folds
    k, rest = 0, num_samples - samples_per_fold * num_folds
    for k in range(rest): indexes[k % num_folds] += 1
    for h in range(1,num_folds): indexes[h] += indexes[h-1]
    return indexes

  def display(self):
    "Display information about the current experiment"
    dname = colored(self.info['name'],'red','on_cyan')
    print("\n---------- dataset {} ----------\n".format(dname))
    #print("Current experiment is on dataset",dname)
    print("Classes are",str(self.info.classes))
    print("Num samples = {}, num features = {}".format(self.num_samples, self.info.num_attrs))
    print("Dataset ratio = {:4.2f}".format(self.info.dratio))
    fnames = str(self.fnames)
    if len(fnames) > 80: fnames = fnames[:70] + ' ... etc ...'
    print("Features:",fnames)
    print("Learner is {})".format(self.learner,self.learner.complexity))
    print()

  def make_title(self,dataset,layer,fold):
    "Make title (see display_statistics)"
    title = "<{}> (layer = {})".format(dataset,layer)
    if type(fold) == int: title = title[:-1] + ", fold = {})".format(fold)
    return title

  def display_manifold_statistics(self,mresults,**kwargs):
    "Display manifold statistics (for kfold cross validation)"
    verbose = kwargs.get('verbose',False)
    for k, results in enumerate(mresults):
      stats, outcomes, cm = results.mget()
      fold = '-fold({})'.format(k+1)
      self.display_statistics(stats,outcomes,fold=fold,verbose=verbose)

  def display_statistics(self,stats,outcomes,fold=None,verbose=False):
    "Display statistics using a phidelt diagram"
    views, dataset = list(), self.dataset
    if verbose:
      for s in stats: s.display()
    for layer, outcome in enumerate(outcomes):
      title = self.make_title(dataset,layer,fold)
      phi, delta, fnames, dratio = outcome
      view = View(phi,delta)
      view.plot(title=title)
      views += [ view ]
    return views      

  def save_manifold_statistics(self,mresults,logfiles,save=tuple(),combo=False):
    "Save manifold statistics (from kfold cross validation or multiple runs)"
    for k, results in enumerate(mresults):
      fold = '-fold({})'.format(k+1)
      self.save_statistics(results,logfiles,save=save,combo=combo,fold=fold)

  def save_statistics(self,results,logfiles,save=tuple(),combo=False,fold=''):
    "Save statistics (cmatrix and/or views)"
    #if 'views' in save: backendHandler().deactivate()
    stats, outcomes, cm = results.mget()
    summaries, exp_runs = logfiles
    settings, shape = mirror(self.learner.settings(),self.learner.shape)
    netinfo  = "Network params (LRate, Momentum, Epochs) are {}\n".format(settings)
    netinfo += "Network shape is {}".format(shape)
    cm.display(comment=netinfo)
    if 'cmatrix' in save:
      stream(summaries) << cm.display(comment=netinfo)
    if 'views' in save:
      views = self.display_statistics(stats,outcomes)
      self.save_views(views,exp_runs,fold,combo=combo)
      time.sleep(1)
      self.delete_views(views)
    #backendHandler().activate()

# -----------------------------------------------------------------------------

if __name__ == '__main__':

  exp = Experiment('iris', path='../datasets/neuralnets/')
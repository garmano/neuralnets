#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 18 14:16:56 2018

@author: armano
"""
import numpy as np

from utils.math         import sigmoid, dsigmoid # sigmoid and its derivate

# ------------------------------ LAYER ----------------------------------------

class Layer(object):
  
  "An MLP layer (which is composed by a pipeline of transducer and connector)"
  
  weights       = property(lambda self: self.transducer.weights)
  complexity    = property(lambda self: self.transducer.complexity)
  
  num_inputs    = property(lambda self: self.transducer.num_inputs)
  inputs        = property(lambda self: self.transducer.inputs)

  num_outputs   = property(lambda self: self.collector.num_units)
  outputs       = property(lambda self: self.collector.outputs)
  
  learning_rate = property(lambda self: self.transducer.learning_rate)
  momentum      = property(lambda self: self.transducer.momentum)
  
  def __init__(self,num_inputs,num_outputs,bias=2,level=0,name=None,**kwargs):
    "Create an MLP layer (with embedded transducer)"
    assert bias in (0,1,2)  # bias = 0 -> no bias, 1 -> +1., 2 -> (+1.,-1.)
    self.level, self.bias = level, bias # level is for debugging only ...
    self.name = name # layer name (optional)
    self.transducer = Transducer(num_inputs,num_outputs,bias,level=level,**kwargs)
    self.collector  = Collector(num_outputs,level=level)
    self.next, self.prev  = None, None # forward and backward propagation links
    self.delta = None
    self.activation_function = (sigmoid,dsigmoid) # default choice
    self.transducer(**kwargs) # push settings (if any) to the transducer

  def settings(self,**kwargs):
    "Push settings to the transducer"
    self.transducer(**kwargs)
    
  def bind(self,layer):
    "Bind two layers with forward and backward links"
    self.next, layer.prev = layer, self
    layer.level = self.level + 1
    
  def prune(self,constraint):
    num_outputs = self.transducer.prune(constraint)
    self.collector.prune(num_outputs)
    if self.next:
      self.next.touch(constraint=constraint) # adapting next layer inputs ...
    return num_outputs

  def touch(self,constraint):
    self.transducer.touch(constraint)

  def as_array(self):
    "See a layer as an array ... (read_only)"
    return np.atleast_2d(self.outputs)

  def propagate_forward(self,inputs,up_to=-1):
    "Propagate the inputs along linked layers"
    pipe = self.transducer.process_forward(inputs)  
    outputs = self.collector.process_forward(pipe)
    if up_to == 0 or not self.next: return outputs
    return self.next.propagate_forward(outputs,up_to-1)

  def propagate_backwards(self,error,back_to=-1):
    "Backpropagate the error (uses learning rate and momentum)"
    self.delta = error * self.activation_function[1](self.collector.outputs)
    if not back_to == 0 and self.prev:
      error = np.dot(self.delta,self.weights.T)
      error = error[:self.num_inputs] # remove bias, if any ...
      self.prev.propagate_backwards(error,back_to-1)
    self.transducer.update(self.delta) # Now update weights ...
    return self.collector.outputs

  def display(self,comment='Displaying layer info'):
    print(comment)
    print("- Layer is {} (level = {})".format(self,self.level))
    print("  Number of inputs is {}".format(self.num_inputs))
    print("  Number of outputs is {}".format(self.num_outputs))
    print("  Bias is {}".format(self.bias))
    print("  Next layer is {}".format(self.next))
    print("  Prev layer is {}".format(self.prev))
    print("  Transducer is {}".format(self.transducer))
    print("  Collector  is {}".format(self.collector))

# ------------------------------ TRANSDUCER -----------------------------------

class Transducer(object):
  
  "A linear transducer (part of Layer)"

  __settings__ = ('learning_rate','momentum')
  
  def set_inputs(self,inputs): self.buffer[:self.num_inputs] = inputs

  def get_inputs(self): return self.buffer[:self.num_inputs]
  
  num_inputs  = property(lambda self: self.num_buffer - 2)
  inputs      = property(get_inputs,set_inputs)
  
  shape       = property(lambda s: (s.num_buffer, s.num_outputs))
  complexity  = property(lambda s: s.num_inputs * s.num_outputs)
  
  def __init__(self,num_inputs,num_outputs,bias=2,level=0,**kwargs):
    "Initialize the transducer"
    self.level       = level # level is just for debugging ...
    self.bias        = bias
    self.num_buffer  = num_inputs + 2 # the buffer must contain bias inputs      
    self.buffer      = np.zeros(self.num_buffer)
    self.buffer[-2:] = +1., -1. # adding bias (should never be changed)     
    self.num_outputs = num_outputs
    self.outputs     = np.zeros(num_outputs)
    self.weights     = np.zeros(self.shape)
    self.deltaw      = np.zeros(self.shape)
    self.reset_weights()
    self(**kwargs)

  def __call__(self,**kwargs):
    "Set transducer parameters"
    [ setattr(self,k,v) for k, v in kwargs.items() if k in self.__settings__ ]
 
  def process_forward(self,inputs):
    "Process an input (forward)"
    self.inputs = inputs
    self.outputs = np.dot(self.weights.T,self.buffer)
    return self.outputs
  
  def prune(self,constraint):
    "Modify the transducer outputs according to a boolean array of constraints"
    self.weights     = (self.weights.T [constraint]).T
    __, num_outputs  = self.weights.shape
    self.outputs     = np.zeros(num_outputs)
    self.num_outputs = num_outputs
    return num_outputs
  
  def touch(self,constraint):
    "Modify the transducer inputs according to a boolean array of constraints"
    constraint = np.array ( list(constraint) + [True,True] ) # adding bias
    self.weights = self.weights[constraint] # bias is still there ...
    self.num_buffer, __ = self.weights.shape
    self.buffer      = np.zeros(self.num_buffer)
    self.buffer[-2:] = +1., -1. # adding bias inputs
    self.deltaw      = np.zeros(self.shape)

  def update(self,delta):
    "Process an input (backwards)"
    #print("Updating tranducer, level = {}".format(self.level))
    buffer, delta = np.atleast_2d(self.buffer), np.atleast_2d(delta)
    dw = np.dot(buffer.T,delta)
    self.weights += self.learning_rate * dw + self.momentum * self.deltaw
    self.deltaw = dw # remember the error (for momentum)

  def reset_weights(self):
    "Reset weights"
    self.weights[...] = ( 2 * np.random.random(self.shape) - 1 ) * 0.25

  def display(self,comment='Displaying transducer info',summary=False):
    "Display tranducer info"
    print(comment)
    print("- Transducer is {} (level = {})".format(self,self.level))
    print("  Shape is {}".format(self.shape))
    if summary: return
    print("  Weights are {} ...etc ...".format(str(self.weights)[:240]))

# ------------------------------ TRANSDUCER -----------------------------------

class Collector(object):
  
  "An activation function for multilayer perceptrons (part of Layer)"
  
  __settings__ = ('activation_function')
  
  def __init__(self,num_units,level=0):
    "Initialize the collector"
    self.level = level # just for debugging ...
    self.num_units = num_units
    self.inputs, self.outputs = np.zeros(num_units), np.zeros(num_units)
    self.activation_function = (sigmoid, dsigmoid)

  def __call__(self,**kwargs):
    "Set collector parameters"
    [ setattr(self,k,v) for k, v in kwargs.items() if k in self.__settings__ ]
 
  def process_forward(self,inputs):
    "Process an input (forward) --- i.e., apply the activation function"
    self.inputs, self.outputs = inputs, self.activation_function[0](inputs)
    return self.outputs
  
  def prune(self,num_units):
    self.num_units = num_units
    self.inputs, self.outputs = np.zeros(num_units), np.zeros(num_units)
    return num_units

  def display(self,comment='Displaying collector info'):
    "Display collector info"
    print(comment)
    print("- Collector is {} (level = {})".format(self,self.level))
    print("  Number of units is {}".format(self.num_units))
    print("  Inputs are {} ...etc ...".format(str(self.inputs)[:120]))
    print("  Outputs are {} ...etc ...".format(str(self.outputs)[:120]))

# ++++++++++++++++++++++++++++++ TESTING ++++++++++++++++++++++++++++++++++++++

if __name__ == '__main__':
  
  input_layer = Layer(30,10,learning_rate=0.01,momentum=0.05)
  hidden_layer = Layer(10,6,learning_rate=0.01,momentum=0.05)
  output_layer = Layer(6,1,learning_rate=0.01,momentum=0.05)
  
  input_layer.next, hidden_layer.prev = hidden_layer, input_layer
  hidden_layer.next, output_layer.prev = output_layer, hidden_layer
  
  layers = input_layer, hidden_layer, output_layer

  for layer in layers:
    layer.display()
  
  sample = np.random.rand(30)
  
  aaa = input_layer.propagate_forward(sample)

  print(aaa)
  
  bbb = output_layer.propagate_backwards(1-aaa)
  
  print(bbb)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 21 19:06:01 2018

@author: armano
"""

# -----------------------------------------------------------------------------

from utils.patterns     import Registry, Singleton

from neuralnets.mlp     import MLP
from neuralnets.mlpp    import MLPP

# -----------------------------------------------------------------------------

@Singleton
class MLRegistry(Registry):
  
  __strategies__ = ('backprop', 'progressive' )
  
  def __init__(self):
    self['backprop'], self['progressive'] = MLP, MLPP
  
  def strategy(self,key): return self[key]

# -----------------------------------------------------------------------------

  
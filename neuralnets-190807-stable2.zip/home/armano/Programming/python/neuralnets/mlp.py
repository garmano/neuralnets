# -*- coding: utf-8 -*-
"""
Created on Sat Jun  2 14:39:22 2018

@author: giuliano armano
"""

# -----------------------------------------------------------------------------
# Object-oriented implementation of multi-layer perceptron with backpropagation
# -----------------------------------------------------------------------------
# Defaults: error function = RMS, activation function = sigmoid
# -----------------------------------------------------------------------------
# Copyright 2018 by G. Armano (distributed under the terms of the BSD License)
# -----------------------------------------------------------------------------

import numpy as np
import math

from utils.performance         import cmatrix # confusion matrix
from utils.iterables           import mget

from layers                    import Layer

from neuralnets.profilers      import mlp_profiler
from neuralnets.error_handling import error_logger

from utils.iterables           import shift_and_zip
from utils.params              import settings, mirror
from utils.printing            import printf # print with "flush"

from mining.cost_functions     import functionRegistry

# -----------------------------------------------------------------------------

flookup = functionRegistry() # activate the registry of cost functions

# ------------------------------ MLP ------------------------------------------

class MLP(object):

  "Multi-layer perceptron (with one or more hidden layers) - NO TRAIN METHOD"

  __settings__      = ( 'learning_rate', 'momentum', 'num_epochs' )

  __display__       = ['learning_rate', 'momentum', 'num_epochs', 'shape',
                       'num_layers', 'num_outputs', 'num_inputs', 'num_hidden_layers' ]
  
  __min_value__     =  0.40
  
  __min_percent__   = 40.00
  
  __min_units__     = 10

  input_layer  = property(lambda s: s.layers[0] if s.layers else None)
  output_layer = property(lambda s: s.layers[-1] if s.layers else None)

  num_inputs   = property(lambda s: s.layers[0].num_inputs if s.layers else None)
  num_outputs  = property(lambda s: s.layers[-1].num_outputs if s.layers else None)
  
  inputs       = property(lambda s: s.layers[0].inputs if s.layers else tuple())
  outputs      = property(lambda s: s.layers[-1].outputs if s.layers else tuple())
  
  num_layers   = property(lambda s: len(s.shape)-1 if s.shape else 0)
  num_hidden_layers = property(lambda s: len(s.shape)-2 if s.shape else 0)
  
  transducers  = property(lambda s: [ layer.transducer for layer in s.layers ])

  complexity   = property(lambda s: sum([ l.complexity for l in s.layers ]))

  def __init__(self,name='auto',**kwargs):
    "Init the neural network (no layers yet)"
    self.name = name
    self.num_epochs, self.learning_rate, self.momentum = 100, 0.01, 0.05
    self.shape, self.layers = tuple(), list()
    self.phidelta_rank = flookup['phidelta_rank5']() # see functionRegistry ...
    self.errors = None
    if kwargs: self.settings(**kwargs)
    
  def __lshift__(self,layers):
    "Add one or more layers to the network"
    if layers not in (tuple,list): layers = (layers,)
    for layer in layers:
      #layer.next = None # cutting off forward links of layer ...
      if not self.layers: self.shape += (layer.num_inputs,)
      else: self.layers[-1].bind(layer)
      self.layers += [ layer ]
      self.shape += (layer.num_outputs,)
    return self

  def settings(self,**kwargs):
    "Set/get the learning parameters"
    if kwargs: # use method as setter (returns self)
      [ setattr(self,k,v) for k, v in kwargs.items() if k in self.__settings__]
      return self
    else: # use method as getter (returns network settings)
      kvpairs = [ ( k, getattr(self,k) ) for k in self.__settings__ ]
      return tuple([ v for k,v in kvpairs ])
    
  def reset_errors(self):
    self.errors = None # e.g., to force the creation of a new error logger ...

  def make(self,*shape):
    "Build network layers"
    self.shape = shape
    layers = self.layers = list()
    kwargs = settings(learning_rate=self.learning_rate,momentum=self.momentum)
    for k, (num_inputs, num_outputs) in enumerate(shift_and_zip(shape)):
      layer_name = f"{self.name}[{k}]"
      layers.append(Layer(num_inputs,num_outputs,level=k,name=layer_name))
    for layer in layers: layer.transducer(**kwargs)
    for k in range(len(layers)-1): layers[k].next = layers[k+1] # forward chain
    for k in range(len(layers)-1): layers[k+1].prev = layers[k] # backward chain
    return self
  
  def make_all_stats(self,data,labels,verbose=0,**kwargs):
    return mlp_profiler(self).make_all_stats(data,labels,verbose=verbose)

  def make_layer_stats(self,data,labels,**kwargs):
    kwargs = mget(kwargs,('up_to','verbose'),output='as_dict')
    return mlp_profiler(self).make_layer_stats(data,labels,**kwargs)
  
  def prune(self,data,labels,layer_ndx=0,**kwargs):
    "Prune a layer according to a phidelta heuristics"
    constraint, verbose = mget(kwargs,('constraint','verbose'))
    xargs = settings(up_to=layer_ndx,verbose=verbose)
    stats, outcomes = self.make_layer_stats(data,labels,**xargs)
    phi, delta, *more = outcomes
    num_units = len(delta)
    ranked = self.rank(phi,delta)
    if constraint: pranked = ranked[:constraint]
    else: pranked = self.iterate_selection(ranked,num_units)
    units = sorted([ k for k,x in pranked ])
    cut_point = len(units)
    if cut_point >= num_units: return num_units # temporary ??? ...
    print("Pruning layer from {} to {} units".format(num_units,cut_point))
    return self.layers[layer_ndx].prune(units)

  def iterate_selection(self,ranked,num_units):
    min_value, min_percent = mirror(self.__min_value__, self.__min_percent__)
    cut_point = math.ceil(num_units * min_percent/100.) # dangerous ??? ...
    cut_point = max(cut_point,self.__min_units__)
    phidelta_rank = self.phidelta_rank
    for j in range(15):  # dangerous ??? ...
      pranked = [ kpd for kpd in ranked if phidelta_rank(kpd) >= min_value ]
      if len(pranked) >= cut_point: break
      min_value = min_value * 0.9       

  def propagate_forward(self, sample, up_to=-1):
    "Propagate data from input layer to output layer"
    return self.input_layer.propagate_forward(sample,up_to=up_to)

  def propagate_backward(self,target,back_to=-1):
    "Back propagate error related to target using learning rate"
    error = target - self.outputs
    self.output_layer.propagate_backwards(error,back_to=back_to)
    return sum(error**2) / len(error) # mean square error

  def train(self, data, labels, comment='', verbose=0, ratio=1.):
    "Train the network (validation set not used, yet ...)"
    if comment: print("\n {}\n".format(comment))
    print("\nTraining network with shape",self.shape)
    if not self.errors: self.errors = error_logger(data,labels,self.num_epochs)
    majority_class, chance = self.set_majority_class(ratio)
    negctr, posctr = 0, 0
    for num_epoch in range(self.num_epochs):
      printf("*",end='\n' if (num_epoch+1) % 50 == 0 else '')
      for num_sample, (sample,label) in enumerate(zip(data,labels)):
        if not self.check_majority_class(label,majority_class,chance): continue
        negctr,posctr = self.conditional_inc(label,negctr,posctr)
        self.propagate_forward(sample)
        error = self.propagate_backward(label)
        self.errors.update(num_epoch,num_sample,error)
      if self.errors.check(): break # yes, the avg error is very low ...
      if verbose > 5: self.errors.display(up_to=100)
    print("\n+++ Processed {} neg and {} pos samples".format(negctr,posctr))
    print("Training ended at epoch {}".format(num_epoch))
    return self
 
  def test(self, data, labels, comment='', verbose=0, ratio=1.):
    "Testing the network"
    if comment: print("\n {}\n".format(comment))
    cm = cmatrix()
    for k, (sample,label) in enumerate(zip(data,labels)):
      output = self.propagate_forward(sample)
      cm.update(label,output)
      if verbose > 15:
        print('%2d: %+4.2f (expected %+4.2f) ' % (k,output[0],labels[k]),end='')
        print('*' if not self.check_output(output[0],labels[k]) else '')
    if verbose > 10: print()
    return cm

  def make_regression(self, data, target, verbose=0):
    "Make regression" # TO BE DONE ...
    num_rows, num_cols = data.shape
    for i in range(self.num_epochs * num_rows):
      n = np.random.randint(data.size)
      self.propagate_forward(data[n])
      self.propagate_backward(target[n])
      
  def transduce(self, data, up_to=-1, output_as='array'):
    "Transduce data using the network"  # could be made more efficient ...
    outputs = list()
    for sample in data:
      self.propagate_forward(sample,up_to=up_to) # no need to propagate onwards
      outputs += [ np.copy(self.layers[up_to].outputs) ]
    return np.array(outputs) if output_as == 'array' else outputs
  
  def rank(self,phi,delta):
    "Sort <phi,delta> pairs (the index of each pair is not lost)"
    phidelta_rank = self.phidelta_rank
    evalues = [ (k,pd) for k, pd in enumerate(zip(phi,delta)) ]
    return sorted(evalues,key=phidelta_rank,reverse=True)

  def conditional_inc(self,label,negctr,posctr):
    "Conditionally increment negative and positive counter"
    if label == -1: return negctr+1, posctr
    if label == +1: return negctr, posctr+1
    raise Exception("Conditional inc error ...")
 
  def set_majority_class(self, ratio):
    "Set the majority class (either -1 or +1)"
    majority_class = -1 if ratio > 1. else 0 if ratio == 1. else +1
    if ratio > 1.: ratio = 1./ratio
    chance = int(1000 * ratio)
    return majority_class, chance

  def check_majority_class(self, label, majority_class, chance):
    "Check the majority class (goal: balancing neg and pos samples)"
    if not label == majority_class: return True
    return chance >= np.random.randint(0,1000)

  def check_output(self, output, target, _range=(-0.99,+0.99)):
    "Check the output (deals with small errors due to floating point approx)"
    mintarget, maxtarget = _range
    if   target > maxtarget: return output > +0.0001
    elif target < mintarget: return output < -0.0001
    raise Exception

  def display(self, comment=''):
    "Display information about the multilayer perceptron"
    if not comment: comment = "Displaying mlp settings"
    print("-------------------------------")
    print("***",comment,"***\n")
    for attr in self.__display__:
      print("{:18} = {}".format(attr,getattr(self,attr,None)))
    print("-------------------------------")
    
  def displayLayers(self,comment=''): # testing only ...
    "Display information about layers"
    if not comment: comment = "Displaying layers ..."
    print("\n",comment,"\n")
    for layer in self.layers:
      layer.display()
      print()
      
  def displayTransducers(self,comment='',summary=False): # testing only ...
    "Display information about transducers"
    if not comment: comment = "Displaying transducers ..."
    print("\n",comment,"\n")
    for layer in self.layers:
      layer.transducer.display(summary=summary)
      print()
      
  def displayErrors(self, epochs=list(), steps=list(), threshold = 0.):
    "Display information about errors"
    if type(epochs) == int: epochs = [ epochs ]
    if type(steps) == int: steps = [ steps ]
    for epoch, step, error in self.errors:
      if epochs and epoch not in epochs: continue
      if steps and step not in steps: continue
      print("Epoch = {:3d} Step = {:3d} Error = {:6.4}".format(epoch,step,error))

  def viewErrors(self, i, back_to = -8):
    "View latest errors (with 'back_to' as parameter, default 8)"
    floats = [ "%4.3f" % value[2] for value in self.errors[back_to:] ]
    print("Epoch = {}\nError = {}".format(i," ".join(floats)))

# ++++++++++++++++++++++++++++++ TESTING ++++++++++++++++++++++++++++++++++++++

if __name__ == '__main__':

  print("Starting MLP test")
  
  data   = np.random.rand(40,30) 
  labels = np.random.randint(0,high=2,size=40) * 2 - 1
  
  mlp = MLP().make(30,10,5)
  
  mlp.display()
 
  mlp.train(data,labels)
  
#  mlp.display() 
#  input, target = np.random.rand(30), np.random.rand(5) 
#  print("\n*** Propagating forward ... ***\n")
#  mlp.propagate_forward(input)  
#  print("*** input  is",input)
#  print("    target is",target)
#  print("    output is",mlp.outputs)
  
#  mlp.displayTransducers("*** Transducers (before) ... ***")
#  mlp.propagate_backward(target)
#  mlp.displayTransducers("*** Transducers (after)  ... ***")
  


#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 23 19:36:38 2018

@author: armano
"""

# -----------------------------------------------------------------------------

from utils.params              import settings, mirror

from neuralnets.mlp            import MLP
from neuralnets.error_handling import error_logger
    
# -----------------------------------------------------------------------------

class MLPP(MLP):
  
  "MLP with progressive training strategy (iteratively uses an MLP 'trainee')"

  __prune__        = True
  
  __derror__       =  0.25

  def __init__(self,name='auto',**kwargs):
    "Init the multilayer perceptron"
    super().__init__(name=name,**kwargs)
    self.final_shape  = None
    self.pconstraints = list()
    self.error_check  = list()
    self.terrors      = list()
    self.trainee      = None
    
  def make(self,*shape): # by default prune all layers with no constraints ...
    "Set the network w/out building network layers"
    self.final_shape, self.initial_shape = list(shape), list(shape)
    self.pconstraints = list([ 1000 ] * (len(shape) - 2))
    self.terrors = list([ 0.01 ] * (len(shape) - 1))
    self.trainee = None
    return self
  
  def set_constraints(self,constraints):
    "Set costraints along the layers"
    self.pconstraints = list(constraints)
      
  def get_constraint(self,at=0):
    "Get the pruning constraint at the k-th layer"
    return self.pconstraints[at]

  def get_netargs(self,at=0):
    return { key : getattr(self,key)[at] for key in self.__settings__ }
  
  def get_num_epochs(self,at=0):
    return self.num_epochs[at]

  def set_errors(self,errors):
    "Set error profile along the layers"
    self.terrors = list(errors)
    
  def get_error(self,at=0):
    "Get the max allowed error at the k-th layer"
    return self.terrors[at]

  def final_shape_at(self,k):
    "Utility for getting the next trainee shape (see 'train')"
    shape = self.final_shape[k:k+2] + [ 1 ]
    if shape[-2] == 1: shape = shape[:-1]
    return shape

  def touch_final_shape_at(self,k,num_units):
    "Change the final shape at a given index"
    self.final_shape[k] = num_units
    
  def reset_final_shape(self):
    "Reset the final shape (back to the initial shape)"
    self.final_shape = list(self.initial_shape)
    
  def permission_to_prune(self,layer_ndx=0):
    "Check whether pruning is allowed (depends on current settings and level)"
    return self.__prune__ and self.pconstraints[layer_ndx]

  def train(self, data, labels, comment='', verbose=0, ratio=1.):
    "Train the network using a progressive strategy"
    self.reset_final_shape()
    tdata, tlabels = mirror(data,labels)
    self.layers, self.shape = list(), tuple()
    print("*** Initial shape is",self.initial_shape)
    for k, num_inputs in enumerate(self.final_shape[:-1]):
      tshape = self.final_shape_at(k)
      print()
      print("*** Training step {} (tshape is {})".format(k,tshape))
      num_epochs, netargs = self.get_num_epochs(at=k), self.get_netargs(at=k)
      self.trainee = MLP(name=self.name).settings(**netargs).make(*tshape)
      derror = self.get_error(at=k)
      self.trainee.errors = error_logger(data,labels,num_epochs,delta_error=derror)
      self.trainee.train(tdata,tlabels,verbose=verbose,ratio=ratio)
      self.trainee.errors.display(up_to=10)     
      if self.permission_to_prune(k):
        print("^^^ Pruning layer",k)
        constraint = None if len(self.pconstraints) <= k else self.pconstraints[k]
        kwargs = settings(layers_ndx=0,constraint=constraint,verbose=verbose)
        num_outputs = self.trainee.prune(tdata,labels,**kwargs)
        self.touch_final_shape_at(k+1,num_outputs)
      ishape, cshape = mirror(self.initial_shape,self.final_shape)
      print("Current shape is {} (initial shape was {})".format(cshape,ishape))
      self << self.trainee.input_layer
      tdata = self.transduce(data,up_to=k)
      if k > 0 and derror: derror *= 0.7 # reduce max error after one step ...
    self.errors = self.trainee.errors
    # self << self.trainee.output_layer # THERE IS A BUG HERE !!! ...
    formatter = "\n*** Final shape is {} (initial shape was {})\n"
    print(formatter.format(self.final_shape,self.initial_shape))
    return self
    
# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  import numpy as np
  
  print("Starting MLPP test")
  
  data   = np.random.rand(40,30) 
  labels = np.random.randint(0,high=2,size=40) * 2 - 1
  
  mlpp = MLPP().make(30,50,25,10,1)
  
  mlpp.train(data,labels)
  
  mlpp.displayLayers()

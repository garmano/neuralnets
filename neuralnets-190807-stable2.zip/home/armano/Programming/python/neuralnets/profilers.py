#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 23 18:07:13 2018

@author: armano
"""

# -----------------------------------------------------------------------------

from phidelta.statistics import Statistics

# -----------------------------------------------------------------------------

class mlp_profiler(object):

  "Tool for making statistics on a multilayer perceptron after training"

  def __init__(self, mlp):
    self.mlp = mlp

  def make_all_stats(self,data,labels,verbose=0):
    statistics, outcomes = list(), list()
    stats, outs = self.make_input_stats(data,labels)
    statistics += [ stats ] ; outcomes += [ outs ]
    for k, layer in enumerate(self.mlp.layers):
      stats, outs = self.make_layer_stats(data,labels,up_to=k)
      statistics += [ stats ] ; outcomes += [ outs ]
    return statistics, outcomes
  
  def make_input_stats(self,data,labels,verbose=0):
    dname = f"{self.mlp.name}[layer=input]"
    stats = Statistics(data,labels,dname=dname)
    return stats, stats.make(verbose=verbose)
  
  def make_layer_stats(self,data,labels,up_to=-1,verbose=0):
    data = self.mlp.transduce(data,up_to=up_to)
    dname = f"{self.mlp.name}[layer={up_to}]"
    stats = Statistics(data,labels,dname=dname)
    return stats, stats.make(verbose=verbose)  
    
# -----------------------------------------------------------------------------

if __name__ == '__main__':

  import numpy as np
  
  from neuralnets.mlp import MLP
  
  data, labels = np.random.rand(50,10), np.random.rand(50)
  
  mlp = MLP().make(10,4,1)
  
  profiler = mlp_profiler(mlp)
  
  #profiler << (data,labels)

# -----------------------------------------------------------------------------

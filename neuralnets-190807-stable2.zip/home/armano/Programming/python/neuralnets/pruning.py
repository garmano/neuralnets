#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 21 13:19:07 2018

@author: armano
"""

class Pruning(object):
  
  "Handler for enforcing pruning strategies on multilayer perceptrons"
  
  def __init__(self):
    pass
  
  def strategy(self):
    pass
  
  
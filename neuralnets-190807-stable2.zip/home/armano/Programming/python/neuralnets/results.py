#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 16 19:09:13 2019

@author: armano
"""

# -----------------------------------------------------------------------------

class Outcome(object):
  
  "Outcomes from and experiment (phi, delta, fnames and ratio)"

  slots = ( 'phi', 'delta', 'fnames', 'dratio' )  # might also be __slots__
  
  def __init__(self,phi,delta,fnames,dratio=1.):
    "Init the outcome wrapper"
    self.phi, self.delta = phi, delta
    self.fnames = fnames
    self.dratio = dratio
    
  def mget(self,*slots):
    "Get some / all slots of an outcome wrapper (multiple get)"
    if not slots: slots = self.slots
    return [ getattr(self,slot,None) for slot in slots ]
  
  def display(self):
    "Display the content of the wrapper"
    print("^^^ Outcomes viewer ^^^")
    print(self.phi)
    print(self.delta)
    print(self.fnames)
    print(self.dratio)

# -----------------------------------------------------------------------------

class Results(object):

  "Results of an expriments (statistics, outcomes, confusion matrix)"
  
  slots = ( 'stats', 'outcomes', 'cm' ) # might also be __slots__
  
  def __init__(self,stats, outcomes, cm):
    "Init the results wrapper"
    self.stats, self.outcomes, self.cm = stats, outcomes, cm
    self.outcomes = [ Outcome(*outcome) for outcome in self.outcomes ]
    
  def __call__(self,*combo):
    "Setter / getter for a results wrapper"
    if not combo: return self.stats, self.outcomes, self.cm
    # otherwise
    self.stats, self.outcomes, self.cm = combo
    self.outcomes = [ Outcome(outcome) for outcome in self.outcomes ]

  def mget(self,*slots):
    "Get some / all slots of a results wrapper (multiple get)"
    if not slots: slots = self.slots
    return [ self.get_slot(slot,None) for slot in slots ]
  
  def get_slot(self,slot,default=None):
    "Get a slot by name (also making outcomes explicit)"
    value = getattr(self,slot,default)
    if slot == 'outcomes': value = [ v.mget() for v in value]
    return value
    
  def display(self):
    "Display the content of the results wrapper"
    print(f"^^^ Statistics: {self.stats}")
    print(f"^^^ Outcomes:   {self.outcomes}")
    print("^^^ Confusion matrix:")
    if self.cm: self.cm.display()
    
# -----------------------------------------------------------------------------

class manifoldResultsHandler(object):
  
  "Handling multiple results (due to multiple runs)"
  
  def __init__(self):
    "Init the manifod results handler"
    self.mresults = list()
    
  def __lshift__(self,combo):
    "Add further results to the handler"
    self.mresults += [ Results(*combo) ]
    
  def __iter__(self):
    "Make the handler iterable"
    return iter(self.mresults)
  
  def display(self):
    "Display the content of the manifold results handler"
    print("^^^ Manifold results viewer ^^^")
    print(self.mresults)
  
# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  pass

# -----------------------------------------------------------------------------

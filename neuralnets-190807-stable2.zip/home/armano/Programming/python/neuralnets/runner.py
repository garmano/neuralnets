# -------------------- EXPERIMENTS --------------------------------------------

# -*- coding: utf-8 -*-
"""
Created on Tue Oct 30 14:53:00 2018

@author: armano
"""

# -----------------------------------------------------------------------------

from utils.date            import get_current_date
from utils.iterables       import mget, unzip2
from utils.params          import settings, mirror
from utils.performance     import performance_logger
from utils.printing        import stream, plist_as_settings

from experiments           import Experiment

from neuralnets.results    import manifoldResultsHandler

from ml_repository         import MLRegistry

# -----------------------------------------------------------------------------

def get_num_runs(repeat):
  "Get the number of runs"
  return repeat

def get_exp_params(kwargs):
  "Get the main parameters of the experiment"
  ekeys, edefs = ('mode','shape','strategy'), ('test',(10,1),'backprop')
  return mget(kwargs,ekeys,edefs)

def get_net_params(kwargs,shape,strategy='backprop'):
  "Get the parameters for the multiplayer perceptron"
  nkeys, ndefs = ('learning_rate','momentum','num_epochs'), (0.01, 0.05, 100)
  LR, momentum, num_epochs = mget(kwargs,nkeys,ndefs)
  if strategy == 'progressive' and type(LR) not in (tuple, list):
    num_trainings = len(shape) + 1
    LR = [ LR ] * len(shape)
    momentum = [ momentum ] * num_trainings
    num_epochs = [ num_epochs ] * num_trainings
  return LR, momentum, num_epochs

def get_xtra_params(kwargs,shape,strategy='backprop'):
  "Get extra parameters for the multiplayer perceptron"
  xkeys = ('pruning','errors')
  pruning, errors = mget(kwargs,xkeys)
  if strategy == 'progressive' and type(pruning) not in (tuple, list):
    num_trainings = len(shape) + 1
    pruning = [ pruning ] * num_trainings
    errors = [ errors ] * num_trainings
  return pruning, errors

# -----------------------------------------------------------------------------

def display_exp_params(mode,shape,strategy):
  "Display the main parameters of the experiment"
  print("    Settings: ", end='')
  eformatter = "Mode = {}, Shape = {}, Strategy = {}"
  print(eformatter.format(mode,shape,strategy))

def display_net_params(learning_rate,momentum,num_epochs):
  "Display the parameters of the multiplayer perceptron"
  print("    Netpars:  ", end='')
  nformatter = "Learning_Rate = {}, Momentum = {}, Num_Epochs = {}"
  print(nformatter.format(learning_rate,momentum,num_epochs))

# -----------------------------------------------------------------------------

class Profiler(object):
  
  __pmeasures__ = ('spec', 'sens', 'acc', 'phi', 'delta')
  
  def __init__(self, name, path='', logger=''):
    "Init the experiment profiler (by default logfile = None)"
    self.name, self.path = name, path
    self.experiment, self.logfile = None, logger
    self.mresults = None # TO BE REMOVED LATER ON ...
    
  def set_logfile(self, logger):
    "Set the log file"
    self.logfile = logger

  def execute(self, experiment, repeat, **kwargs):
    "Execute a multiple-test run on a dataset"
    start = get_current_date(remove=tuple(),strip=tuple())
    mresults = self.make_multiple_tests(experiment,repeat,**kwargs)
    avg_cm, measures = self.eval_averages(mresults)
    end = get_current_date(remove=tuple(),strip=tuple())
    self.to_logfile(start,end,avg_cm,measures)
    self.experiment = experiment # TO BE REMOVED LATER ON ...
    return mresults
  
  def to_logfile(self, start, end, avg_cm, measures):
    logfile = self.logfile
    stream(logfile) << print("  --start('{}')".format(start))
    stream(logfile) << self.display_cm_average(avg_cm,wrapper="  --cmatrix")
    stream(logfile) << self.display_report(measures)
    stream(logfile) << print("  --end('{}')".format(end))
    stream(logfile) << print()

  def make_multiple_tests(self, experiment, repeat, **kwargs):
    "Utility for running multiple tests (on a given dataset)"
    num_runs, exp = get_num_runs(repeat), experiment
    mode, shape, strategy = get_exp_params(kwargs)
    if mode == 'kfold' and num_runs == 1: num_runs = 2 # WORKAROUND ...
    LRate, momentum, num_epochs = get_net_params(kwargs,shape=shape,strategy=strategy)
    netargs = settings(learning_rate=LRate,momentum=momentum,num_epochs=num_epochs)
    constraints, errors = get_xtra_params(kwargs,shape=shape,strategy=strategy)
    num_samples, num_attrs = mirror(exp.num_samples, exp.num_attrs)
    learner = MLRegistry()[strategy] # choose a learner from the ML registry
    train_percent, dratio = kwargs.get('train_percent',70), exp.info.dratio
    xkwargs = settings(train_percent=train_percent,verbose=False,ratio=dratio)
    if mode == 'kfold': exp.make_kfolds(num_samples,num_runs)
    stream(self.logfile) << self.display_test_info(repeat, kwargs)
    formatter = settings(swrapper="  --samples",fwrapper="  --features")
    stream(self.logfile) << exp.info.display_as_settings(**formatter)
    mresults = manifoldResultsHandler()
    for k in range(num_runs):
      print("\n\n^^^ RUN NUMBER {} of dataset {} ^^^\n\n".format(k+1,self.name))
      exp.learner = learner(exp.name,**netargs).make(exp.num_attrs,*shape)
      if strategy == 'progressive':
        if constraints: exp.learner.set_constraints(constraints)
        if errors: exp.learner.set_errors(errors)
      mresults << self.make_test(experiment,k,mode,shape,strategy,**xkwargs)
    self.mresults = mresults # TO BE REMOVED LATER ON ...
    return mresults

  def make_test(self, experiment, step, mode, shape, strategy, **kwargs):
    "Make a train, tran and test, or a kfold run for a given dataset)"
    exp = experiment
    print("*** Processing dataset",self.name)
    display_exp_params(mode,shape,strategy)
    data, labels, dratio = mirror(exp.fdata, exp.flabels, exp.info.dratio)
    num_samples, num_attrs = exp.fdata.shape
    if   mode == 'train':
      kwargs['train_percent'] = 100 # train on the whole dataset
      results = exp.train_and_test(data,labels,shuffle=True,**kwargs)
    elif mode == 'test':
      if not 'train_percent' in kwargs: kwargs['train_percent'] = 50
      results = exp.train_and_test(data,labels,shuffle=True,**kwargs)
    elif mode == 'kfold':
      if 'train_percent' in kwargs: del kwargs['train_percent'] # WORKAROUND ...
      results = exp.keyfold_step(data,labels,step=step,**kwargs)
    else:
      raise Exception(f"Mode {mode} not implemented!!")
    return results
    
  def eval_averages(self, mresults,pmeasures=None):
    "Evaluate perfomance averages"
    if not pmeasures: pmeasures = self.__pmeasures__
    plogger = performance_logger()
    for results in mresults:
      stats, outcomes, cm = results.mget()
      plogger << cm
    avg_cm = plogger.eval_cm_average()
    return avg_cm, list(zip(pmeasures,plogger.multi_performance(pmeasures)))
  
  def display_test_info(self,repeat,kwargs):
    print("  --repeat({})".format(repeat))
    doargs  = mget(kwargs,('mode','shape','strategy'),output='as_dict')
    netargs = mget(kwargs,('learning_rate','momentum','num_epochs'),output='as_dict')
    xtrargs = mget(kwargs,('constraints','pruning','errors'),output='as_dict')
    if doargs:
      print("  --doargs({})".format(plist_as_settings(doargs.items())))
    if netargs:
      print("  --netargs({})".format(plist_as_settings(netargs.items())))
    if xtrargs:
      print("  --xtrargs({})".format(plist_as_settings(xtrargs.items())))
    
  def display_cm_average(self,values,wrapper=None):
    formatter = "TN={:2.4f}, FP={:2.4f}, FN={:2.4f}, TP={:2.4f}"
    if wrapper: formatter = "{}({})".format(wrapper,formatter)
    print(formatter.format(*values))

  def display_report(self,mresults):
    names, rest = unzip2(mresults)
    means, variances = unzip2(rest)
    print("  --performance({})".format(plist_as_settings(zip(names,means))))
    print("  --variance({})".format(plist_as_settings(zip(names,variances))))

# -----------------------------------------------------------------------------

if __name__ == '__main__':

  def set_verbose_strategy(strategy):
    if strategy == 'b': return 'backprop'
    if strategy == 'p': return 'progressive'
    raise Exception("Strategy name should be 'backprop' or 'progressive'")
  
  from datastream.cparser    import cmd_parser

  from datastream.about      import about
  from datastream.logging    import logger

  from utils.graphics        import backendHandler
  from utils.debugging       import keys
  
  about, keys # to avoid warning ...
  
  backendHandler().activate() # just to be sure ...
  
  # ---------- HERE COMES THE COMMAND (could also be manifold) ----------------

  # dataset
  # dataset       = 'medical-diagnosis-1'
  # dataset       = 'medical-diagnosis-2'
  # dataset       = 'iris'
  
  dataset        = 'WBC'
  
  # number of iterations
  num_runs      = 1
  
  # training ode and shape
  mode          = 'test'
  shape         = (20, 1)
  strategy      = 'b'  # 'b' <--> 'backprop', 'p' <--> 'progressive' 
  
  strategy      = set_verbose_strategy(strategy)


  # ---------- strategy == 'backprop' ----------
  
  if strategy == 'backprop':

    # network parameters
    LR            = 0.01     # learning rate
    M             = 0.05     # momentum
    nep           = 100      # num_epochs
    pruning       = None
    errors        = None

  # ---------- strategy == 'progressive' ----------
  
  if strategy == 'progressive':
  
    LR         = 0.01
    M          = 0.05
    nep        = 40
    pruning    = None
    errors     = None

    # eXtra arguments
    
    #  LR       = (0.005, 0.01, 0.001, 0.001, 0.001)
    #  M        = (0.01, 0.05, 0.02, 0.01, 0.005)
    #  nep      = (50, 50, 70, 100, 100)
    #  pruning  = (None, None, None, None, None)
    #  errors   = (0.15,0.10, 0.05, 0.01, 0.005)
  
    # LR       = (0.05, 0.01, 0.005)
    # M        = (0.1, 0.05, 0.002)
    # nep      = (50, 50, 50)
    # pruning  = (None, None, None)
    # errors   = (0.15,0.10, 0.05)

  # command in string format

  dset = f"""@dataset '{dataset}'
               --repeat({num_runs})
               --do(mode='{mode}', shape={shape}, strategy='{strategy}')
               --netargs(learning_rate={LR}, momentum={M}, num_epochs={nep})
               --xtrargs(pruning={pruning},errors={errors})"""

  # ---------------------------------------------------------------------------
  
  verbose = False
  display = True
  
  path  = '../datasets/neuralnets/'
  
  epath, lpath = logger.get_paths('exp','summaries')
  
  cp = cmd_parser() ; cp << dset ; cmd = cp.parse()[0] # single run ...
  
  summaries = logger.set_logfile(name=cmd.dname,context='summaries')
  exp_runs  = logger.set_logfile(name=cmd.dname,context='exp')

  # logfiles, save = (summaries,exp_runs), ('views',)
  
  logfiles, save = (summaries,exp_runs), ('views',)
  
  prof  = Profiler(cmd.dname,path=path,logger=summaries)
  
  stream(summaries) << print("@dataset '{}'\n".format(cmd.dname))

  # many runs but only one experiment ...

  experiment = Experiment(dataset=cmd.dname,path=path)

  for crun in cmd.runs:
    kwargs = dict(crun.doargs,**crun.netargs,**crun.xtrargs)
    mresults = prof.execute(experiment,repeat=crun.repeat,**kwargs)
    experiment.save_manifold_statistics(mresults,logfiles=logfiles,save=save)
    
  if display: experiment.display_manifold_statistics(mresults,verbose=verbose)
 
#  exp = prof.experiment
#  
#  fnames, fdata, flabels = mirror(exp.fnames,exp.fdata,exp.flabels)
#  
#  stats = Statistics(fdata,flabels,dname=dataset)
#  
#  phi, delta, __, ratio = stats.make(fnames=fnames)
#  
#  bestf = stats.sort(fnames,phi,delta)

# ----------------------------------------------------------------------

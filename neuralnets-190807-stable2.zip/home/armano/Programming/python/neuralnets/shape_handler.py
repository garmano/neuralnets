#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 20 19:06:52 2018

@author: armano
"""

# -----------------------------------------------------------------------------

from utils.mining     import make_constraint

# -----------------------------------------------------------------------------

class NetPars(object):
  
  "Relevant parameters for multilayer perceptrons"
  
  __constraints__ = { 'shape':      lambda self: self.sconstraints,
                      'functional': lambda self: self.fconstraints,
                      'profile':    lambda self: self.pconstraints,
                      'errors':     lambda self: self.econstraints }
  
  initial = property(lambda self: (self.num_inputs,) + self.ishape)
  final   = property(lambda self: [self.num_inputs]  + self.fshape)
  
  def __init__(self):
    "Init the parameters' repository"
    self.num_inputs, self.num_layers = 0, 0
    self.ishape, self.fshape = tuple(), list()
    self.sconstraints = list() # shape      constraints
    self.fconstraints = list() # functional constraints
    self.pconstraints = list() # pruning    constraints
    self.econstraints = list() # error      constraints
    
  def update(self,num_units,at=0):
    "Update the final shape of the k-th layer"
    self.fshape[at] = num_units

  def shape(self, num_inputs, ishape, fshape=None):
    "Set a new shape (with initial and final shape)"
    fshape = fshape if fshape else ishape
    assert len(ishape) == len(fshape)
    self.num_inputs, self.num_layers = num_inputs, len(ishape)
    self.ishape = tuple(ishape)
    self.fshape = list(fshape)
    self.reset_constraints()
    return self

  def functional(self,command,at=0):  # not sure if it is useful ...
    "Add a functional constraint to the k-th layer"
    if type(command) is str: command = make_constraint(command)
    self.fconstraints[at] = command
    
  def pruning(self,command,at=0):
    "Update the pruning constraint of the k-th layer"
    if type(command) is str: command = make_constraint(command)
    self.pconstraints[at] = command

  def error(self,command,at=0):
    "Update the error constraint of the k-th layer"
    if type(command) is str: command = make_constraint(command)
    self.econstraints[at] = command

  def reset_constraints(self):
    self.sconstraints = [ lambda s: True for x in self.fshape ]
    self.fconstraints = [ lambda s: True for x in self.fshape ]
    self.pconstraints = [ lambda s: True for x in self.fshape ]
    self.econstraints = [ lambda s: True for x in self.fshape ]

  def errors(self, minmax=(0.1,1.0)):
    "Set a new error profile (linear decrement)"
    min_error, max_error = minmax
    derror = float(max_error - min_error) / len(self.ishape)
    self.errors = list()
    for k, x in enumerate(self.ishape): # linear decrement of the error
      self.error(eval("lambda e: e <={}".format(max_error - k * derror)), at=k)
  
  def check(self,value,at=0,which='shape'):
    assert which in self.__constraints__
    constraint = self.__constraints__[which]
    return constraint(self)[at](value)
  
  def display(self,comment='Displaying net parameters'):
    num_inputs, num_layers = self.num_inputs, self.num_layers
    ishape, fshape = self.ishape, self.fshape
    print("*** {} ***".format(comment))
    print("Num_inputs = {}, num_layers = {}".format(num_inputs, num_layers))
    print("Initial shape = {}".format(ishape))
    print("final   shape = {}".format(fshape))

# -----------------------------------------------------------------------------
    
if __name__ == '__main__':
  
  np = NetPars()
  
  np.shape(num_inputs=34,ishape=(100,40,1),fshape=(40,20,1))
  
  np.display()
  
  np.errors()
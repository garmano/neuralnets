# -*- coding: utf-8 -*-
"""
Created on Sat Mar 29 13:50:14 2014

@author: armano
"""

from phidelta.model import phidelta as phidelta_model

from phidelta.view import phidelta as phidelta_view

from utils.iterables import unzip2

from utils.numbers import epsilon

epsilon

class functionDrawer(object):

  model_methods = [ 'get_ss_grid', 'get_grid', 'get_entropy' ]

  view_methods = [ 'show', 'scatter2D', 'scatter3D' ]
  
  def __init__(self, model=None, view=None):
    self.model, self.view = model, view

  def __call__(self, **kwargs):
    [ setattr(self,key,val) for key, val in kwargs.items() ]

  def entropy2D ( self, borders = True, mode = ('grid', 'entropy') ):
    "Scattering 2D (specific for entropy view)"
    X,Y = unzip2(self.model.get('grid' if 'grid' in mode else 'ss_grid')) 
    if 'entropy' in mode or 'IG' in mode: E = self.model.eval_entropy(mode)
    self.view('fill', 'borders', 'crossings', 'axes')
    self.view.set(labels = self.view.get_labels(mode))
    self.view.scatter2D ( X, Y, E )

  def entropy3D ( self, borders = True, mode = ('grid','entropy') ):
    "Scattering 3D (specific for entropy view)"
    X, Y = None, None
    if 'ss_grid' in mode: # only for DEBUGGING ...
      X, Y = unzip2(self.model.ss_grid) ; E = [ 0. for x in X ]
    if 'grid' in mode:
      self.view.set(labels = ('$\phi$', '$\delta$', 'entropy') )
      X, Y = unzip2(self.model.grid) ; E = [ 0. for x in X ]
    if 'entropy' in mode or 'IG' in mode:
      if not X or not Y: X, Y = unzip2(self.model.grid)
      E = self.model.eval_entropy(mode=mode)
    self.view('fill', 'borders')
    self.view.set(labels = self.view.get_labels(mode=mode), borders = borders)
    #self.view.set(projection = '3d')
    self.view.scatter3D(X,Y,E)

    
if __name__ == '__main__':
  
  phidelta_controller = phidelta  
  
  model = phidelta_model(ratio=1., intervals = 25, _eval = 'all')
  
  view = phidelta_view(model = model)
  
  controller = phidelta_controller(model=model, view=view)
  
  #k.scatter3D(_intervals = 50, _mode = ('phi-delta', 'entropy'))
  
  #X, Y, Z = model.get('ss_grid', 'grid', 'entropy')
  
  #view.scatter2D ( X, Y, Z )
  
  #model.select ( e_bounds = ('max', numbers.epsilon) )
  
  #model.select ( e_bounds = ('max', numbers.epsilon) )

  #model.select ( e_bounds = (0.5, 0.51) )

  # model.select ( e_bounds = (0.70, 0.71) )
  
  view('fill','axes', 'borders', 'crossings')
  
  #controller.entropy2D(mode = ('grid', 'IG'))

  controller.entropy3D(mode = ('grid', 'IG'))

  #controller.entropy3D(mode = ('grid', 'IG'))

  #controller.entropy2D(mode = ('grid', 'IG'))


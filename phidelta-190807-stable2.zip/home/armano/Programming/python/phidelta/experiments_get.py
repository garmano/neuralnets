# -*- coding: utf-8 -*-
"""
Created on Mon Feb  5 16:49:19 2018

@author: armano
"""

pass # TESTING ONLY ...

# ------------------------- MAIN PROGRAM --------------------------------------

if __name__ == '__main__':
  
  from phidelta.statistics import Statistics
  from phidelta.loader import Loader
  from phidelta.view import View

  print("\nEXPERIMENTS\n")
  
#  datasets = ( 'arrhythmia', ('balloons', 1), ('balloons', 2), \
#               'breast-cancer', 'census', 'chess', 'fars', 'flare', \
#               'kr-vs-k', ('lymphography', 1), ('lymphography', 2), \
#               'mushroom', 'SPECT-binary', 'SPECT-full', 'splice' )

#  datasets = ( 'arrhythmia', ('balloons', 1), ('balloons', 2), \
#               'breast-cancer', 'chess' )

#  datasets = ( 'arrhythmia', ('balloons', 1), ('balloons', 2), 'flare' )

#  datasets = ( 'SPECT-full', 'arrhythmia', 'mushroom', 'kr-vs-k' )

#  datasets = ( 'SPECT-full', )

  datasets = ( 'breast-cancer', )

  loader = Loader(path='../datasets/UCI datasets/')
    
  for k, dname in enumerate(datasets):
    data, labels, info = loader.get(dname)
    stats = Statistics(data=data,labels=labels,info=info)
    phi, delta, fnames, dratio = stats.make()
    View(phi,delta).plot(title=dname)

# -----------------------------------------------------------------------------

# -*- coding: utf-8 -*-
"""
Created on Sat Mar 29 13:50:14 2014

@author: armano
"""

# -----------------------------------------------------------------------------

import numpy            as np

from itertools          import product

from phidelta.geometry  import Geometry

from utils.iterables    import unzip2, unzip
from utils.numbers      import numbers

# -----------------------------------------------------------------------------

class Isometrics(object):
  
  "Tool for handling isometrics"

  __fitting__ = { 'linear': 1, 'quadratic': 2, 'cubic': 3 }

  def __init__(self, intervals=10, domain=(-1.,+1), density=0.001):
    "Init the isometric handler"
    self.intervals, self.domain, self.density = intervals, domain, density
    self.fitting = None

  def __call__(self, X, Y, Z):
    "Call the isometric handler"
    return self.select(X,Y,Z) if self.fitting else self.naive_select(X,Y,Z)

  def fit(self,mode=None):
    "Set the fitting mode of the isometric handler (naive vs. smart)"
    self.fitting = self.__fitting__[mode] if type(mode) is str else mode
    return lambda X, Y, Z: self.__call__(X, Y, Z)

  def naive_select(self,X,Y,Z):
    "Naive selector"
    minval, maxval = self.domain
    intervals, density = self.intervals, self.density
    isovalues = np.linspace(minval,maxval,intervals+1)
    ndx = list()
    for h, value in enumerate(Z):
      check = [ numbers.approx(value,ival,diff=density) for ival in isovalues ]
      if True not in check: continue
      ndx += [ h ]
    return X[ndx], Y[ndx], Z[ndx]
    
  def select(self, X, Y, Z): # NOT WORKING YET !!!
    "Smart selector"
    minval, maxval = self.domain
    intervals = self.intervals
    isovalues = np.linspace(minval,maxval,intervals+1)
    indexes = self.build_indexes(Z,isovalues)
    XYZ = list()
    for k, ndx in enumerate(indexes):
      if not ndx: continue # skip empty ndx ...
      Xnew, Ynew = self.approximate_neg(X[ndx],Y[ndx],isovalues[k])
      XYZ += [ (x,y,isovalues[k]) for x, y in zip(Xnew,Ynew) ]
      Xnew, Ynew = self.approximate_pos(X[ndx],Y[ndx],isovalues[k])
      XYZ += [ (x,y,isovalues[k]) for x, y in zip(Xnew,Ynew) ]
    return unzip(XYZ)

  def build_indexes(self, values, isovalues):
    "Buid separate indexes for smart selection"
    indexes = [ list() for k in range(self.intervals+1) ]
    for k, isoval in enumerate(isovalues):
      for h, value in enumerate(values):
        if not numbers.approx(value,isoval,diff=self.density): continue
        indexes[k] += [ h ]
    return indexes

  def approximate_neg(self, X, Y, isovalue):
    "Approximate isometrics (neg area)"
    ndx = np.where(Y<=0)
    Xneg, Yneg = X[ndx], Y[ndx]
    if len(Xneg) < 2: return X, Y
    if np.min(Xneg) == np.max(Xneg): return X, Y
    poly = np.poly1d(np.polyfit(Xneg,Yneg,self.fitting))
    minval, maxval, intervals = np.min(Xneg), np.max(Xneg), Xneg.size
    Xnew = np.linspace(minval,maxval,intervals)
    Ynew = poly(Xnew)
    XY = [ (x,y) for x,y in zip(Xnew,Ynew) if self.domain_check(x,y) ]
    return unzip2(XY)
  
  def approximate_pos(self, X, Y, isovalue):
    "Approximate isometrics (pos area)"
    ndx = np.where(Y>=0)
    Xpos, Ypos = X[ndx], Y[ndx]
    if len(Xpos) < 2: return X, Y
    if np.min(Xpos) == np.max(Xpos): return X, Y
    poly = np.poly1d(np.polyfit(Xpos,Ypos,self.fitting))
    minval, maxval, intervals = np.min(Xpos), np.max(Xpos), Xpos.size
    Xnew = np.linspace(minval,maxval,intervals)
    Ynew = poly(Xnew)
    XY = [ (x,y) for x,y in zip(Xnew,Ynew) if self.domain_check(x,y) ]
    return unzip2(XY)

  def domain_check(self, x, y):
    "Check whether the point is inside the phidelta rhombus"
    if abs(x) + abs(y) > 1.0: return False
    return True

# -----------------------------------------------------------------------------

class Grid(Geometry):
  
  "Grid utility to display functions (only standard phidelta coordinates)"
  
  shape   = property(lambda self: self.grid.shape)
  
  def __init__(self, intervals = 10):
    "Init the grid (default is 10x10)"
    self.intervals = intervals
    self.ss_grid   = self.eval_ss_grid(intervals)
    self.grid      = self.eval_grid(intervals)
    
  def __call__(self, function, on = 'ss_grid'):
    "Gets the values of a function on a grid (either grid or ss_grid)"
    grid = self.grid if on == 'grid' else self.ss_grid
    return [ function(x,y) for x,y in grid ]
  
  def values (self, on='ss_grid'):
    return self.grid if on == 'grid' else self.ss_grid

  def eval_grid(self,intervals=10,reset=False):
    "Evaluate a <phi,delta> grid (default size = 10x10)"
    if reset: self.eval_ss_grid(intervals=intervals)
    grid = [ self.coord(x,y) for x,y in self.ss_grid ]
    return grid

  def eval_ss_grid(self,intervals=10):
    "Evaluate a <spec,sens> grid (default size = 10x10)"
    nx = ny = intervals
    xspace, yspace = np.linspace(0, 1, nx+1), np.linspace(0, 1, ny+1)
    ss_grid = [ (x,y) for x,y in product(xspace,yspace) ]
    return ss_grid

  def coords(self, ss_coords):
    "Transforms <spec,sens> coords into <phi,delta> coords"
    return [ self.coord(spec,sens) for spec, sens in ss_coords ]

  def coord(self, spec, sens):
    "Transforms a pair of <spec,sens> coords into a pair of <phi,delta> coords"
    return sens - spec, sens + spec - 1

  def phi(self, spec, sens):
    "Gets the phi component corresponding to spec-sens"
    phi, delta = self.coord(spec,sens)
    return phi

  def delta(self, spec, sens):
    "Gets the delta component corresponding to spec-sens"
    phi, delta = self.coord(spec,sens)
    return delta
  
  def apply(self, function, on='grid', selector=None):
    "Apply a function (points selection may optionally apply)"
    Z = [ function((k,phidelta)) for k, phidelta in enumerate(self.values(on=on)) ]
    X, Y = unzip2(self.values(on='grid'))
    X, Y, Z = np.array(X), np.array(Y), np.array(Z)
    if selector: X, Y, Z = selector(X,Y,Z)
    return X, Y, Z

# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  from mining.measures       import Entropy, InfoGain, Precision, NegPredValue
  
  from mining.cost_functions import FRegistry
  
  from phidelta.view       import View

  entropy, infogain = Entropy(), InfoGain()
  precision, npv = Precision(), NegPredValue()
  
  fregistry = FRegistry()
  
  on        = 'grid' # can be 'grid' or 'ss_grid'
  domain    = (-1.,+1.) # can be (-1.,+1.) or (0.,1.)
  intervals = 20
  density   = 0.01
  
  iso = Isometrics(intervals,domain,density).fit('quadratic')

  test_function = fregistry['CF18']()

  #X, Y, Z = Grid(40).apply(entropy, on=on, selector=iso.fit('quadratic'))
  X, Y, Z = Grid(50).apply(test_function, on=on, selector=None)

  View(X,Y).scatter3D(Z,colors=Z)
  View(X,Y).scatter2D(colors=Z)

# -----------------------------------------------------------------------------

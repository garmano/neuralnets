# -*- coding: utf-8 -*-
"""
Created on Thu Feb  1 10:21:34 2018

@author: armano
"""

# -----------------------------------------------------------------------------

import numpy as np

import matplotlib.pyplot as plt

from mpl_toolkits.mplot3d import Axes3D

from phidelta.model    import phidelta_std2gen
from phidelta.geometry import Geometry

from utils.iterables   import unzip2, mget
from utils.params      import options, settings
from utils.printing    import remove_quoting
from utils.numbers     import numbers

Axes3D

# -----------------------------------------------------------------------------

class View(Geometry):
 
  "Phidelta view (model, view, controller design pattern)"
 
  __settings__ = settings(s=8,linewidth=2,cmap='jet') # plot settings
  
  __options__  = options('axes','borders','crossings','fill') # plot options

  # see docs for cmap values (e.g., 'hsv', 'brg', 'Purples', 'Reds', ...)

# -----------------------------------------------------------------------------

  def __init__(self, phi, delta, names=None, ratio=1.):
    "Initialize a view object for phidelta diagrams"
    super().__init__(ratio=ratio)
    self.phi, self.delta = phidelta_std2gen(phi,delta,ratio=ratio)
    self.names = names
    self.settings = dict(self.__settings__)
    self.options  = ('axes','borders','fill')
    self.figure, self.axes = None, None

  def __lshift__(self,items): # plot options/settings controller (add/update)
    "Activate phidelta 'plot' options or settings"
    if type(items) == str: items = (items,)
    if type(items) in (tuple,list,set): self.add_options(items)
    elif type(items) == dict: self.update_settings(items)
    else: print("{} are not valid options / settings ...".format(items))
    return

  def __rshift__(self,items): # plot options controller (del)
    "Deactivate phidelta 'plot' options"
    if type(items) == str: items = (items,)
    if type(items) in (tuple,list,set): self.del_options(items)
    else: print("{} are not valid options ...".format(items))
    return

  def plot(self, title='', colors=None, **kwargs):
    "Plot 2D data" # names not used yet ...
    self.scatter2D(title=title,colors=colors, **kwargs)
    
  def close(self):
    "Close a figure (the figure will be deleted)"
    plt.close(self.figure)
    
  def scatter2D(self, title='', colors=None, **kwargs):
    "Scattering 2D (the optional parameter C may control colors)"
    phi, delta = np.array(self.phi), np.array(self.delta)
    if not self.figure: self.plot_shape2D(title=title)
    if colors is None: colors = 1. - np.abs(self.delta)
    kwargs = dict(kwargs,**self.settings)
    self.axes.scatter(phi,delta,c=colors,**kwargs)
    plt.show()

  def scatter3D(self, Z, title='', colors = None, shadow=True, **kwargs):
    "Scattering 3D (the optional parameter C may control colors)"
    phi, delta = np.array(self.phi), np.array(self.delta)
    zeros = np.zeros(phi.size)
    if not self.figure: self.plot_shape3D(title=title)
    if colors is None: colors = numbers.normalize_values(Z)
    ax, kwargs = self.axes, settings(c=colors, alpha=0.05)
    if shadow: ax.scatter(phi, delta, zeros, **dict(kwargs, **self.settings))
    cmap = plt.get_cmap('viridis')
    ax.set_xlim3d(-1.,1.) ; ax.set_ylim3d(-1.,1.)
    # ; self.axes.set_zlim3d(0.,1.)
    kwargs = settings(c=colors, alpha=0.80, cmap=cmap, zorder=3)
    ax.scatter(phi, delta, Z, **dict(kwargs,**self.settings))
    plt.show()

  def plot_shape2D(self, title=''):
    "Shows a phidelta diagram"
    self.figure = plt.figure()
    kwargs = settings(aspect = 'equal')
    self.axes = self.figure.add_subplot(111, **kwargs)
    self.set_title(title) ; self.set_limits()
    if 'axes' in self.options: self.draw_axes()
    if 'borders' in self.options: self.draw_borders()
    if 'crossings' in self.options: self.draw_crossings()
    if 'fill' in self.options: self.fill()

  def plot_shape3D(self, title=''):
    "Shows a phidelta diagram"
    self.figure = plt.figure()
    kwargs = settings(aspect = 'equal', projection='3d')
    self.axes   = self.figure.add_subplot(111, **kwargs)
    self.set_title(title) ; self.set_limits()
    if 'axes' in self.options: self.draw_axes()
    if 'borders' in self.options: self.draw_borders()
    if 'crossings' in self.options: self.draw_crossings()
    self.axes.tick_params(axis='both', which='major', labelsize=8)
    self.axes.tick_params(axis='both', which='minor', labelsize=7)

# -----------------------------------------------------------------------------

  def add_options(self,optList):
    options = set(self.options)
    [ options.add(opt) for opt in optList if opt in self.__options__ ]
    self.options = list(options)
    return self

  def del_options(self,optList):
    options = set(self.options)
    [ options.discard(opt) for opt in optList ]
    self.options = list(options)
    return self

  def update_settings(self,kwargs): # scatter options controller (add)
    "Set options for pyplot.scatter"
    if not kwargs: self.settings = self.__settings__
    for k, v in kwargs.items():
      if not k in self.__settings__: continue
      self.settings[k] = self.__settings__[k] if v == None else v
    return self

# -----------------------------------------------------------------------------

  def set_title(self,title=''):
    "Set the title of a plot (removing quotes if needed)"
    self.axes.set_title(remove_quoting(title))

  def set_limits(self):
    "Set limits of a phidelta diagram"
    xmin, ymax, xmax, ymin = mget(self.limits,self.limit_keys)
    self.axes.set_xlim(xmin, xmax) ; self.axes.set_ylim(ymin, ymax)
    
  def draw_axes(self):
    "Draw axes of a phidelta diagram"
    xmin, ymax, xmax, ymin  = mget(self.limits,self.limit_keys)
    self.axes.plot([0.,0.],[-1.,1.], color = 'b', zorder=1)
    self.axes.plot([xmin,xmax],[0.,0.], color = 'b', zorder=1)
    
  def draw_borders(self):
    "Draw borders of a phidelta diagram"
    X, Y = unzip2(mget(self.borders,self.border_keys))
    self.axes.plot ( X + X[:1], Y + Y[:1], color='r', zorder=1 )

  def draw_crossings(self):
    "Draw crossings of a phidelta diagram"
    left, top, right, bottom = mget(self.borders,self.border_keys)
    X, Y = zip(left,right)
    self.axes.plot ( X, Y, color='0.5', linestyle='dashed', zorder=1 )
    X, Y = zip(top,bottom)
    self.axes.plot ( X, Y, color='0.5', linestyle='dashed', zorder=1 )

  def fill(self,size=160):
    "Fill the background of a phidelta diagram"
    X, Y = unzip2(mget(self.borders,self.border_keys))
    self.axes.fill ( X + X[:1], Y + Y[:1], color='lightgrey', zorder=0 )

# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  from phidelta.statistics import Statistics
  from datastream.loader   import Loader

  from utils.debugging     import runCtrl
  from utils.params        import options, settings
  
  import model

  run = runCtrl()
  
  run << settings(grid=True,random=False,data=False,settings=False,p3D=True)

  if run['p3D']:

    phi, delta = model.make_grid(size=10)
    Z = np.random.rand(phi.size)
    view = View(phi,delta)
    view.scatter3D(Z)

  if run['grid']:

    phi, delta = model.make_grid(size=20)
    view = View(phi,delta)
    view.scatter2D()  

  if run['random']:

    phi, delta = model.random_samples(nsamples=100) 
    view = View(phi,delta)
    view.plot()
    
  if run['data']:
    
    dataset = 'breast-cancer'
    path = "../datasets/UCI datasets/"
    data, labels, info = Loader(path=path).get(dataset)
    phi, delta, names, ratio = Statistics(data,labels,info).make(verbose=True)
    view = View(phi,delta,names,ratio=ratio)
    view.plot(title=dataset)

  if run['settings']:
    
    phi, delta = model.make_grid(size=10)

    view = View(phi,delta,ratio=2.)
    view << options('fill','crossings','axes')
    view << settings(s=14,cmap='plasma') # jet, plasma, cool, ...
    view.plot(title='Testing view settings and options')

# -----------------------------------------------------------------------------

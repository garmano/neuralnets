#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 19:20:37 2018

@author: armano
"""

  # FORMULAS:
  # entropy, IG = H, HClass - H
  # H = - n * spec * negH - p * sens * posH
  # negH = ( log2(neg_prec) + nk * log2(nk * neg_prec / R) / R)
  # posH = ( log2(prec) + k * log2(k * prec * R) * R)
  
# ---------------------------------------------------------------------------
  
    def select(self, ss_bounds = None, g_bounds = None, e_bounds = None):
    _ss_grid, _grid = self.get_ss_grid(force=True), self.get_grid(force=True)
    _entropy = self.get_entropy(force=True)
    e_bounds = self.check_entropy_bounds(e_bounds)
    XYZ = list()
    for (x,y), (gx,gy), e in zip(_ss_grid, _grid, _entropy):
      if not self.check2 ( x, y, ss_bounds ): continue
      if not self.check2 ( gx, gy, g_bounds ): continue
      if not self.check(e, e_bounds): continue
      XYZ += [ ( (x,y), (gx,gy), e ) ]
    XY, PD, E = unzip(XYZ) if XYZ else ( tuple(), tuple(), tuple() )
    self.ss_grid, self.grid, self.entropy = [ np.array(L) for L in (XY,PD,E) ]
    return self.ss_grid, self.grid, self.entropy

  def check_bounds(self,bounds):
    if not bounds: return bounds
    _elevel, _edelta = bounds
    if not ( _elevel in ('min', 'max') ): return bounds
    fun = { 'max': max, 'min': min}[_elevel]
    _max = fun(self.entropy) + _edelta
    _min = fun(self.entropy) - _edelta
    return ( _min, _max )

  def check(self, x, bounds):
    _min = bounds[0] if bounds else numbers.minimum - 1
    _max = bounds[1] if bounds else numbers.maximum + 1
    if x < _min or x > _max: return False
    return True

  def check2(self, x, y, bounds2):
    xbounds = bounds2[:2] if bounds2 else tuple()
    ybounds = bounds2[2:] if bounds2 else tuple()
    return self.check(x,xbounds) and self.check(y,ybounds)
  
# ---------------------------------------------------------------------------

  from view import phidelta as phidelta_view

  def tester(intervals = 100, verbose = False):
    model = phidelta(intervals = intervals)
    view = phidelta_view(model = model)
    view('axes', 'borders') ; ax = view.plot()
    for s in (0., 0.5, 1.):
      spec, sens = np.ones(intervals) * s, np.arange(0., 1., 1./intervals)
      phi, delta = unzip(model.coords(zip(spec,sens)))
      view.scatter2D(phi, delta, ax = ax)
    for s in (0., 0.5, 1.):
      spec, sens = np.arange(0., 1., 1./intervals), np.ones(intervals) * s
      phi, delta = unzip(model.coords(zip(spec,sens)))
      view.scatter2D(phi, delta, ax = ax)
      
  def scatter(spec_array, sens_array, ratio = 1., intervals = 100, colors = None):
    model = phidelta(ratio = ratio, intervals = intervals)
    view = phidelta_view(model = model)
    view('axes', 'borders') ; ax = view.plot()
    spec, sens = spec_array, sens_array
    phi, delta = unzip(model.coords(zip(spec,sens)))
    view.scatter2D(phi, delta, C = colors, ax = ax)

# -----------------------------------------------------------------------------
    
  #tester(50)

  #(phi, delta), (spec, sens) = tester(100, verbose = True)
  
  #model = phidelta(ratio=1., intervals = 100, _eval = 'all')
  
  #XYZ = model.select(ss_bounds = (0.5,1.,0.5,1.))
  #XYZ = model.select(e_bounds = ('max',0.000001))

  #spec = np.array([0.95,0.75,0.84,0.79,0.82,0.75,0.04])
  #sens = np.array([0.1,0.72,0.64,0.84,0.69,0.85,0.97])

  #spec = np.array([0.95,0.95, 0.05])
  #sens = np.array([0.05,0.95,0.95])
  #colors = np.array([0.2,0.6,0.9])

  #scatter(spec,sens,ratio=0.1,colors=colors)
  
  #tester(100)
  
  # Multiple test with Orange (breast cancer wisconsin)
  #spec = np.array([0.9707, 0.97072, 0.9639, 0.9819, 0.9527])
  #sens = np.array([0.9707, 0.8912, 0.9665, 0.9372, 0.9205])
  #colors = np.array([0.2,0.4,0.6,0.8,0.95])
  #model = phidelta(ratio=1., intervals = 100)
  #scatter(spec,sens,ratio=1.,colors=colors)

# ---------------------------------------------------------------------------
  
    def scatter2D(self, title='', colors=None, **kwargs):
    "Scattering 2D (the optional parameter C may control colors)"
    phi, delta = self.phi, self.delta
    if not self.figure: self.plot_shape(title=title,projection='2d')
    if colors is None: colors = 1 - np.abs(delta)
    cmap = plt.cm.get_cmap('gnuplot2') # map = 'gnuplot2' | 'RdYlBu' | 'PiYG'
    self.axes.scatter(phi, delta, c = colors, cmap = cmap, **self.settings)
    #if title: self.set_title_options(title,ax=self.axes)
    #self.axes.legend()
    plt.show()
  
  def scatter3D(self, Z, title='', colors = None, **kwargs):
    "Scattering 3D (the optional parameter C may control colors)"
    phi, delta = self.phi, self.delta
    #self.axes.scatter ( phi, delta, zeros, color = '0.75', alpha=0.5)
    if not self.figure: self.plot_shape(title=title,projection='3d')
    if colors is None: colors = numbers.normalize_values(Z)
    #ax.set_xlim3d(-1.,1.) ; ax.set_ylim3d(-1.,1.) ; ax.set_zlim3d(0.,1.)
    cmap = plt.get_cmap('viridis') # cmap = 'hsv', 'brg', 'Purples', 'Reds', ...
    #ax.set_xlim3d(-1.,1.)
    #self.axes.set_ylim3d(-1.,1.) ; self.axes.set_zlim3d(0.,1.)
    self.axes.scatter(phi, delta, Z, c=colors, cmap=cmap, alpha=0.75, zorder=3)
    plt.show()
  
# ---------------------------------------------------------------------------

#def eval_coords(ss_coords, ratio = 1.):
#  "Transforms several spec-sens coords into phidelta coords"
#  return [ eval_coord(x,y,ratio) for x, y in ss_coords ]
#
#def eval_coord(spec, sens, ratio = 1.):
#  "Transforms a pair of spec-sens coords into a pair of phidelta coords"
#  p, n =  1. / (1. + ratio), ratio / (1. + ratio)
#  _phi = 2 * ( p * sens - n * spec) + 2 * (n-p)
#  _delta = 2 * ( p * sens + n * spec) - 1
#  return _phi, _delta

# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
  
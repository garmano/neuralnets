# -*- coding: utf-8 -*-
"""
Created on Mon Feb  5 16:49:19 2018

@author: armano
"""

import matplotlib.pyplot as plt

from utils import np_abs

from statistics import cStatistics

from model import model

from view import view


if __name__ == '__main__':
  
  print("\nEXPERIMENTS\n")
  
  # working_dir = '/Users/armano/python/phidelta/'
  
  # os.chdir(working_dir)
  
  datasets    = '../datasets/UCI datasets/'
  
  # STATISTICS

  stats = cStatistics(path=datasets)
  
  #stats.load('arrhythmia.csv',header=False)

  #stats.load('autos.csv',index=0,header=False)

  #stats.load('balloons.csv',header=False,classes=('T','F'))

  #stats.load('balloons2.csv',header=False,classes=('T','F'))

  #stats.load(filename='breast-cancer.csv',
  #           classes = ('recurrence-events', 'no-recurrence-events'))

  #stats.load('census.csv', classes = ('50000+.','-_50000.'))
         
  #stats.load('chess.csv', classes = ('won','nowin'))

  #injury = 'Incapaciting_Injury,Fatal_Injury'.split(',')
  #other  = 'No_Injury,Possible_Injury,Nonincapaciting_Evident_Injury, \
  #          Injured_Severity_UDisplaying fnknown,Died_Prior_to_Accident,Unknown'.split(',')
  #stats.load('fars.csv', classes = (injury,other))

  #stats.load(filename='flare.csv', classes = (('B','C','D'),('E','H','F')))
  
  #draw = 'draw'
  #win = 'zero, one, two, three, four, five, six, seven, eight, nine, ten, \
  #       eleven, twelve, thirteen, fourteen, fifteen, sixteen'.split(',')
  #stats.load('kr-vs-k.csv',classes = (draw,win))

  #stats.load('lymphography.csv',
  #           classes=(('normal','fibrosis'),('metastases','malign_lymph')))

  #stats.load('lymphography.csv',
  #           classes=('normal',('metastases','malign_lymph','fibrosis')))

  #stats.load('mushroom.csv', classes = ('e','p'))

  #stats.load('SPECT-full.csv',sep=';',header=False,index=0)

  #stats.load('SPECT-binary.csv', index=0, classes=('1','0'))

  #stats.load('splice.csv', classes = ('EI',('IE', 'N')))

  stats.make()

  #cmats = stats.score()

  #stats.displayStatistics(mode='normalized')

  # RANKING
  
  stats.display_ranking()

  # VISUALIZATION

  v = view(model=model(ratio=1.),title= stats.name)
  
  v << ('axes', 'borders', 'crossings', 'fill')
  
  v.options(s=4,linewidth=2,cmap=plt.get_cmap('jet')) # try: plasma, rainbow, jet
  
  nmats, fhooks = stats.flatten_nmats()

  phi, delta = v.model.coords(nmats=nmats)
  
  v.plot_data(phi,delta,colors=np_abs(delta))


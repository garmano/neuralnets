#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 18:31:46 2018

@author: armano
"""

import numpy as np

nx, ny = (10,10)

x, y = np.linspace(0, 1, nx+1), np.linspace(0, 1, ny+1)

xv, yv = np.meshgrid(x, y, sparse=False, indexing='ij')
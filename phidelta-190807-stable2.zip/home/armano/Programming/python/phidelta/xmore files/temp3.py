#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 23 13:00:22 2018

@author: armano
"""

import matplotlib.pyplot as plt
import numpy as np

x = np.array([0.0, 1.0, 2.0, 3.0,  4.0,  5.0])
y = np.array([0.0, 0.8, 0.9, 0.1, -0.8, -1.0])

coeffs = np.polyfit(x, y, 3)

p = np.poly1d(coeffs)

#p10 = np.poly1d(np.polyfit(x, y, 10))

xp = np.linspace(-2, 6, 100)

plt.plot(x, y, '.')

plt.plot(xp, p(xp), '-')

#plt.plot(xp, p10(xp), '--')

plt.ylim(-2,2)

plt.show()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 23 16:45:43 2018

@author: armano
"""

import numpy as np

import matplotlib.pyplot as plt

xL = np.array([ 0.14,  0.08, -0.08, -0.14,  0.14,  0.08, -0.08, -0.14])

yL = np.array([-0.86, -0.88, -0.88, -0.86,  0.86,  0.88,  0.88,  0.86])

XY = list(zip(xL,yL))


#x = np.array([0.0, 1.0, 2.0, 3.0,  4.0,  5.0])
#y = np.array([0.0, 0.8, 0.9, 0.1, -0.8, -1.0])

coeffs = np.polyfit(x, y, 3)

p = np.poly1d(coeffs)

xnew = np.linspace(-2,6,50)

#ynew = poly.polyval(xnew, coeffs)

#plt.plot(x, y,'-', xnew, p(xnew), '--')

plt.plot(x, y,'-')

plt.ylim(-2,2)

plt.show()
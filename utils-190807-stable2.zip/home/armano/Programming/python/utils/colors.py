#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 10 13:08:27 2018

@author: armano
"""

import colorama

import termcolor
  
from utils.iterables import mget
from utils.params import settings

def text(item,fg=None,bg=None):
  return settings(text=item,fg=fg,bg=bg)
  
class coloredStream(object):
  
  def __init__(self,foreground='black',background='on_white'):
    colorama.init()
    self.def_foreground, self.def_background = foreground, background
    
  def __lshift__(self,kwargs):
    text, foreground, background = mget(kwargs,('text','fg','bg'))
    if not foreground: foreground = self.def_foreground
    if not background: background = self.def_background
    print(termcolor.colored(text,foreground,background))
      
if __name__ == '__main__':
  
  cs = coloredStream()
  
  cs << text("ciccio",fg='green')
  

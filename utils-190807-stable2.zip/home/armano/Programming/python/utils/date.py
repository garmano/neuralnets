# -*- coding: utf-8 -*-
"""
Created on Mon Aug 20 15:54:41 2018

@author: armano
"""

from datetime import date
from datetime import datetime

def current_date(format='tiny'):
  if not format in ('tiny','normal'): raise Exception()
  cdate = str(date.today())
  return cdate if format == 'normal' else cdate.replace('-','')[2:]

def get_current_date(remove=('hh','mm','ss'),strip=('-',':')):
  remove = (remove,) if type(remove) == str else remove
  strip  = (strip,)  if type(strip)  == str else strip
  yymmdd, hhmmss = str(datetime.now()).split()
  hhmmss, __ = hhmmss.split('.') # removing milliseconds ...
  hh, mm, ss = hhmmss.split(':')
  hh = '' if 'hh' in remove else hh
  mm = '' if 'mm' in remove else mm
  ss = '' if 'ss' in remove else ss
  hhmmss_sep = '' if ':' in strip else ':'
  hhmmss = hhmmss_sep.join((hh,mm,ss))
  yymmdd = yymmdd.replace('-','') if '-' in strip else yymmdd
  yymmdd = yymmdd[2:] # yymmdd instead of yyyymmdd ...
  return yymmdd if not hhmmss else "{} ({})".format(yymmdd,hhmmss) 

if __name__ == '__main__':

  print(current_date(format='tiny'))
  
  print(get_current_date(remove=tuple(),strip=tuple()))
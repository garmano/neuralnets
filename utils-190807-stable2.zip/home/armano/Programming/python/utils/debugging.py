# -----------------------------------------------------------------------------

from utils.patterns import Singleton

# -----------------------------------------------------------------------------
# ------------------------ DEBUGGING ------------------------------------------
# -----------------------------------------------------------------------------

def keys(obj):
  if type(obj) == dict: return obj.keys()
  elif getattr(obj,'__dict__',None): return obj.__dict__.keys()
  elif getattr(obj,'__slots__',None): return obj.__slots__
  else: return type(obj)
  
@Singleton
class Debug(object):

  "Debug control (singleton)"
  
  def __init__(self,level=99):
    "Init debug"
    self.debug_level = level # range(0,100), with 0 = debug-all, 99 = no-debug

  def __call__(self,level=1,mode = 'inc'):
    "Debug update (allowed modes are 'inc', 'dec', 'set')"
    if   mode == 'inc': self.debug_level += level
    elif mode == 'dec': self.debug_level -= level
    elif mode == 'set': self.debug_level  = level
    self.print_level()
    return self.level

  def print_debug_level(self):
    "Print current debug level"
    print("Debugging level is {:2d}".format(self.level))

# -----------------------------------------------------------------------------

class runCtrl(object):
  
  "Utility for selecting which SW procedures should be run"
  
  def __init__(self,*args,**kwargs):
    self.runDict = dict()
    for arg in args: self.runDict[arg] = True
    self.__lshift__(kwargs)
    return
    
  def __call__(self,*keys,**kwargs):
    if kwargs: [ self.runDict.update({key: val}) for key, val in kwargs ]
    values = [ self.runDict.get(key,tuple()) for key in keys ]
    if len(values) == 1: return values[0]
    return values
    
  def reset(self,keys='all'):
    if keys == 'all': keys = self.runDict.keys()
    [ self.runDict.pop(key) for key in keys ]
    
  def __lshift__(self,kwargs):
    for key, value in kwargs.items(): self.runDict[key] = value
    return self
    
  def __getitem__(self,key): return self.runDict.get(key,None)
    
  def __setitem__(self,key,value): self.runDict[key] = value
    
  def __delitem__(self,key): self.runDict.pop(key,None)
      
  def __str__(self): return str(self.runDict)
  
  def get(self,key,default=None):
    return self.runDict.get(key,default)

# -----------------------------------------------------------------------------
 
def debug(comment,*args,**kwargs):
  print("{} : ".format(comment),end='')
  print(*args,**kwargs)

# -----------------------------------------------------------------------------


if __name__ == '__main__':
  
  from utils.params import settings

  ctrl = runCtrl('eee','ooo',zoo='zot')

  ctrl << settings(foo='oops',mmap=True)
  
  print(ctrl.runDict)
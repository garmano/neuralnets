# -*- coding: utf-8 -*-
"""
Created on Thu Feb  1 11:36:08 2018

@author: armano
"""


import numpy as np

from itertools import product


# -----------------------------------------------------------------------------
# ------------------------ FILES R/W ------------------------------------------
# -----------------------------------------------------------------------------

def load_csv_data(filename, path='',sep=','):
  print("Loading file {} ...".format(path+filename))
  with open(path+filename) as infile:
    return [ line.strip().split(sep) for line in infile ]
    
def save_csv_data(content, filename, path='',sep=','):
  print("Saving data to file {} ...".format(path+filename))
  with open(path+filename,"w") as outfile:
    for items in content:
      # assert type(items) in (tuple,list,set)
      for k, item in enumerate(items):
        if k > 0: outfile.write(", ")
        outfile.write(str(item))
      outfile.write("\n")

# -----------------------------------------------------------------------------


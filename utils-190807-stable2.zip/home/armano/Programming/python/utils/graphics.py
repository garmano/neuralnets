#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 17 13:53:17 2019

@author: armano
"""

# -----------------------------------------------------------------------------

import matplotlib

# -----------------------------------------------------------------------------

from utils.patterns import Singleton

# -----------------------------------------------------------------------------

@Singleton
class backendHandler(object):
  
  "Handler for changing matplotlib backend"
  
  def __init__(self):
    "Init the backend handler"
    self.default_backend = self.current_backend = matplotlib.get_backend()
    self.no_backend = 'Agg' # non interactive backend

  def deactivate(self):
    # matplotlib.use(self.no_backend)
    matplotlib.use(self.no_backend,warn=False)
    self.current_backend = self.no_backend
    
  def activate(self):
    matplotlib.use(self.default_backend)
    self.current_backend = self.default_backend
    
  def toggle(self):
    self.activate() if matplotlib.get_backend() == 'Agg' else self.deactivate()
      
# -----------------------------------------------------------------------------

if __name__ == '__main_':
  
  pass

# -----------------------------------------------------------------------------
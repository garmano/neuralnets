# -----------------------------------------------------------------------------
# ----------------------------- IMPORT SECTION --------------------------------
# -----------------------------------------------------------------------------


import numpy as np


# -----------------------------------------------------------------------------
# ------------------------ LISTS, TUPLES, DICTS -------------------------------
# -----------------------------------------------------------------------------

def unzip2(values):
  "Unzip a list of pairs (accepts also arrays)"
  to_array = type(values) == np.ndarray
  X, Y = [ x for x, y in values ], [ y for x, y in values ]
  return (np.array(X), np.array(Y)) if to_array else (X, Y)

def unzip(values):
  "Unzip a list of tuples (accepts also arrays)"
  if type(values) in (tuple,list) and len(values) == 0: return list() 
  num_lists = len(values[0])
  outlist = [ list() for k in range(num_lists) ]
  for item in values:
    for k in range(num_lists):
      outlist[k] += [ item[k] ]
  return outlist

def shift_and_zip(L):
  return [ x for x in zip(L[:-1],L[1:]) ]

def make_pairwise(L):
  return [ (L[k],L[k+1]) for k in range(0,len(L),2) ]

def flatten_SAVE(L):
  "Unfold the content of a list (outputs a flat list)"
  outlist = list()
  for item in L:
    if type(item) in (tuple, list): outlist += flatten(item)
    else: outlist.append(item)
  return outlist

def flatten(iterable,depth=1,output_as=tuple):
  "Unfold the content of a list (outputs a flat list)"
  outlist = list()
  for x in iterable:
    outlist += [ x ] if not type(x) in (tuple,list) else x
  if depth > 1: return flatten(outlist,depth-1,output_as=output_as)
  return output_as(outlist)

# -----------------------------------------------------------------------------

def mset(adict,keys,values=None):
  "Set multiple keywords"
  if not values: values = [ None for k in keys ]
  for key, value in zip(keys,values): adict[key] = value

def mget(adict,keys,defaults=None,output='as_list'):
  "Get multiple keywords"
  if not defaults: defaults = [ None for k in keys ]
  values = [ adict.get(key,value) for key, value in zip(keys,defaults) ]
  return dict(zip(keys,values)) if output == 'as_dict' else values

# -----------------------------------------------------------------------------

def mergeDicts(adict,*more_dicts):
  outdict = dict(adict)
  for d in more_dicts:
    outdict = dict(outdict,**d)
  return outdict

# -----------------------------------------------------------------------------

class adict(dict):
  
  "Advanced dictionary (with default values handling)"
  
  def __init__(self,L=list()):
    "Init the dictionary"
    if L: super().__init__(L)
    self.dvalues = dict() # default values are here ...
  
  def __getitem__(self,key):
    "Get a value starting from a key (defaults may apply)"
    if key in self: return super().__getitem__(key)
    else: return self.dvalues.get(key)

  def __lshift__(self,kwargs): # that's multiple_set
    "Insert new <key,value> pairs or modify existing ones"
    if type(kwargs) in (tuple,list): kwargs = dict(kwargs)
    for key, value in kwargs.items(): self[key] = value
    
  def mget(self,keys): # stands for "multiple_get"
    "Get multiple values from the dictionary"
    return [ self[key] for key in keys ]
    
  def default(self,key,value):
    "Set the default value associated to a key"
    self.dvalues[key] = value
    
  def defaults(self,kwargs=None):
    "Set / get default values (behaves as getter if no input is given)" 
    if kwargs is None: return self.dvalues
    if type(kwargs) in (tuple,list): kwargs = dict(kwargs)
    for key, value in kwargs.items(): self.default(key,value)
    
# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  pctrl = adict()

  pctrl << {'ciccio': 10, 'oops':20}
  
  pctrl.default('zap',33)
   
  print(pctrl.defaults())

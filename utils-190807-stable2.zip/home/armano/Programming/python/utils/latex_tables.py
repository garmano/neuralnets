#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul  5 18:29:43 2019

@author: armano
"""

# -----------------------------------------------------------------------------

from operator import itemgetter

# -----------------------------------------------------------------------------

def to_float(item):
  try: item = float(item)
  except: pass
  return item

def to_strings(items,decimals=2):
  outlist = list()
  for item in items:
    if type(item) is float: item = "{:4.2f}".format(round(item,decimals))
    outlist += [ str(item) ]
  return outlist

# -----------------------------------------------------------------------------

class LatexFormatter(object):
  
  def __init__(self, filename, path=''):
    self.filename, self.path = filename, path
    self.content, self.features = list(), list()
    self.keywords = ('dataset','difficulty','spec','sens','acc')
    self.indexes = list()
    self.values = list()
    self.table = dict()

  def load(self):
    with open(self.path + self.filename) as infile:
      buffer = [ line.strip() for line in infile ]
    self.features = buffer[0].split(';')
    self.features = features = [ feature.strip() for feature in self.features ]
    self.content = [ line.split(';') for line in buffer[1:] ]
    self.content = [ items for items in self.content if items and items[0] ]
    self.indexes  = [ k for k, f in enumerate(features) if f in self.keywords ]
    
  def select(self):
    self.values = [ self.select_values(values) for values in self.content ]
    
  def select_values(self,values):
    return [ to_float(value) for k, value in enumerate(values) if k in self.indexes ]
  
  def make_latex_table(self):
    self.table = dict()
    for vlist in self.values:
      dname, difficulty, *measures = vlist  # first item is the dataset name
      self.table.setdefault ( dname, [dname,difficulty.strip()] )
      self.table[dname] += measures
    return
  
  def display(self,leading_blanks=4):
    priority = lambda lst: lst[0].lower()
    for results in sorted(self.table.values(),key=priority):
      print(' ' * leading_blanks, end='')
      print(" & ".join ( to_strings(results)), end='')
      print(" \\\\")
      
# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  epath = epath = "../experiment summaries/csvfiles/runs 190708/"
  
  LF = LatexFormatter("runnerlog-19-07-08.csv",path=epath)
  
  LF.load()
  
  LF.select()
  
  LF.make_latex_table()
  
  LF.display()

# -----------------------------------------------------------------------------

    
# -*- coding: utf-8 -*-
"""
Created on Mon Jun  4 13:29:28 2018

@author: armano
"""

#import math

# -----------------------------------------------------------------------------

import numpy as np

import math

from utils.numbers  import numbers

# -----------------------------------------------------------------------------

def log2(x):    # evaluates log(p)
  if x < 0. or x > 1.: raise Exception
  if numbers.approx(x,0): return numbers.minimum
  return math.log(x,2)

def plog2(x,y=1.,z=1.):   # evaluates p*log(p)
  _min, _max = min(x,y,z), max(x,y,z)
  if _min < 0. or _max > 1.: raise Exception
  if numbers.approx(_min,0): return numbers.minimum
  _prod = x * y * z
  return _prod * math.log(_prod,2)

# -----------------------------------------------------------------------------

def sigmoid(x):
    "Sigmoid like function using tanh"
    return np.tanh(x)

def asigmoid(x,bias=-1.):
  "A sigmoid"
  return (1 / (1 + np.exp(-x))) - 0.5
  
def dsigmoid(x):
    "Derivative of sigmoid above"
    return 1.0-x**2

# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------

import numpy as np

import math

from itertools import product

# -----------------------------------------------------------------------------

def numeric(item):
  if type(item) == str: return False
  try: float(item)
  except: return False
  return True
  
def to_numeric(item,default=None):
  try: return float(item)
  except: return item if not default else default

def numeric_to_string(item,formatter="{:2.4f}"):
  if "." not in str(item):
    try: return str(int(item))
    except: pass
  else:
    try: return formatter.format(float(item))
    except: pass
  return str(item)

def array1D_to_numeric(array,default=None):
  outarray = np.ndarray(array.shape,dtype=object)
  for h in range(array.shape[0]):
    outarray[h] = to_numeric(array[h],default=default)
  return outarray

def array1D_find_minmax(data_slice):
  return np.min(data_slice), np.max(data_slice)

def array2D_to_numeric(array,default=None):
  outarray = np.ndarray(array.shape,dtype=object)
  num_rows, num_cols = array.shape
  for h, k in product(range(num_rows),range(num_cols)):
    outarray[h,k] = to_numeric(array[h,k],default=default)
  return outarray
  
def array2D_find_minmax(data_array):
  num_rows, num_cols = data_array.shape
  minvalues, maxvalues = np.zeros(num_cols), np.zeros(num_cols)
  for k, column in enumerate(data_array.T):
    minvalues[k], maxvalues[k] = np.min(column), np.max(column)
  return minvalues, maxvalues  

# -----------------------------------------------------------------------------

class numbers(object):

  maximum, minimum, epsilon = 10000000., -10000000., 0.00000001
  
  fdict = { 'linear': lambda x: x, 'square': lambda x: x*+2,
             'exp': math.exp, 'log': math.log, 'log2': lambda x: math.log(x,2) }

  @staticmethod
  def approx(var, value, diff=0.0000001):
    return abs(var-float(value)) < diff
  
  @staticmethod
  def erange(_min, _max, _intervals=10):
    _delta = abs(_max - _min) / _intervals
    _array = np.zeros(_intervals + 1)
    for k in range(_intervals+1): _array[k] = k * _delta
    return _array

  @classmethod
  def normalize_value(cls, value, _min = 0., _max = 1., _mode = 'linear'):
    _percent = abs ( value - _min ) / ( _max - _min )
    return cls.fdict[_mode] ( _percent )
  
  @staticmethod
  def normalize_values(values, _min = 0., _max = 1., _mode = 'linear'):
    fun = numbers.fdict[_mode]
    _out = [ fun ( abs ( val - _min ) / ( _max - _min ) ) for val in values ]
    return _out

  @staticmethod
  def check(fval, fvalues):
    for fvalue in fvalues:
      if numbers.approx(fval,fvalue): return True
    return False

# -----------------------------------------------------------------------------

np_hex = np.vectorize(hex) # Vectorized int --> hex conversion

np_abs = np.vectorize(abs) # Vectorized int --> abs conversion

np_int = np.vectorize(int) # Vectorized int --> int conversion

def normalize_SAVE(data):
  for k, fvalues in enumerate(data.T):
    try:
      fvalues = fvalues.astype(np.float)
      minvalue, maxvalue = array1D_find_minmax(fvalues)
      if maxvalue - minvalue > 0.0001: # reasonable threshold ...
        data[:,k] = data[:,k] / float(maxvalue-minvalue)
      else:
        data[:,k] = 0.
    except:
      print("There are problems with data normalization!")
  return data

def normalize(data): # This normalization could be improved ...
  for k, fvalues in enumerate(data.T):
    try:
      fvalues = fvalues.astype(np.float)
      minvalue, maxvalue = array1D_find_minmax(fvalues)
      deltam = maxvalue - minvalue
      #print(k,minvalue,maxvalue,deltam,data[:,k])
      if deltam > 0.0001: # reasonable threshold ...
        data[:,k] = -1. + 2 * ( data[:,k] - minvalue ) / deltam
      else:
        data[:,k] = 0.
    except:
      print("There are problems with data normalization!")
  return data.astype(float)

# -----------------------------------------------------------------------------


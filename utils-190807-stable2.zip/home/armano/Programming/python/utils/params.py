# -----------------------------------------------------------------------------

options  = lambda *args: args
services = lambda *args: args
mirror   = lambda *args: args

settings = lambda **kwargs: kwargs
store    = lambda **kwargs: kwargs

# -----------------------------------------------------------------------------

class MBox(object):
  
  "Generic container for embedding data"
  
  def __init__(self,*keys):
    "Init the container"
    self.__keys__ = keys
    [ setattr(self,key,None) for key in keys ]
    
  def __lshift__(self,values):
    "Set all values of the container"
    [ setattr(self,key,val) for key, val in zip(self.__keys__,values) ]
    return self
    
  def __call__(self,*keys):
    "Get all / some values from the container"
    if not keys: keys = self.__keys__
    return [ getattr(self,key) for key in keys if key in self.__keys__ ]

  def __getitem__(self,key,default=None):
    "Get a value from the container (returns None if key is not there)"
    return getattr(self,key,default)

  def __setitem__(self,key,value):
    "Set an attribute as dict key (if key is *already* a slot)"
    if key in self.__keys__: setattr(self,key,value)
    
  def display(self,comment='MBox'):
    "Display the keys of the container"
    for key in self.__keys__:
      print(key,getattr(self,key))
    
# -----------------------------------------------------------------------------

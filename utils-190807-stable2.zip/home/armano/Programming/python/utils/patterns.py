# -----------------------------------------------------------------------------
# ------------------------ DESIGN PATTERNS -----------------------------------
# -----------------------------------------------------------------------------

class Singleton(object):
  
  "An implementation of the singleton design pattern"
  
  def __init__(self,cls):
    "Init the singleton"
    self.cls, self.obj = cls, None

  def __call__(self,*args,**kwargs):
    "Call the singleton (only one object is created, at the first call)"
    if not self.obj: self.obj = self.cls(*args,**kwargs)
    return self.obj

# -----------------------------------------------------------------------------

class Registry(dict):
  
  "Generic repository for shared information"
  
  def __init__(self): super().__init__()

  def __getitem__(self,key): return super().get(key,None)

# -----------------------------------------------------------------------------

class Actor(object):
  
  "Class that allows to implement actor-oriented programming style"
  
  def become(self,cls):
    "Changing the class of self"
    self.__class__ = cls

# -----------------------------------------------------------------------------

class constraint(object):
  
  "Naive constraint checker (implicit 'and')"
  
  def __init__(self, **kwargs):
    "Init the constraint checker"
    for k, val in kwargs.items():
      if callable(val): setattr(self,k,val)
      else: setattr(self,k,eval("lambda s: s == '{}'".format(val)))
   
  def check(self,**kwargs):
    "Call the constraint checker"
    for k, val in kwargs.items():
      item_checker = getattr(self,k,None)
      if not item_checker: continue # continue if the constraint does not apply ...
      if not item_checker(val): return False
    return True
  
  def recursive_check(self,**kwargs):
    "Call the constraint checker (recursively visiting the dict tree)"
    for k, val in kwargs.items():
      if not type(val) == dict:
        item_checker = getattr(self,k,None)
        if not item_checker: continue
        if not item_checker(val): return False
      else:
        if not self.recursive_check(**val): return False
    return True

# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  cc = constraint(mode='test',strategy='backprop',shape=lambda s: len(s) > 2)
  
  print("OOOPPPSS", cc.check(mode='test',shape=(30,20,10,1)))
  
  
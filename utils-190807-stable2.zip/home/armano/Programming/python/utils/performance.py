#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov  6 12:54:35 2018

@author: armano
"""

# -----------------------------------------------------------------------------

import numpy as np

import random

# -----------------------------------------------------------------------------

class cmatrix(object):

  "Naive implementation of a confusion matrix"
  
  __items__ = ( 'TN', 'FP', 'FN', 'TP' )

  neg         = property(lambda self: self.TN + self.FP)
  pos         = property(lambda self: self.FN + self.TP)
  all         = property(lambda self: self.neg + self.pos)
  
  spec        = property(lambda self: self.eval_specificity())
  sens        = property(lambda self: self.eval_sensitivity())
  acc         = property(lambda self: self.eval_accuracy())
  
  phi         = property(lambda self: self.eval_phi())
  delta       = property(lambda self:self.eval_delta())

  def __init__(self):
    "Init the confusion matrix"
    self.TN = self.FP = self.FN = self.TP = 0
    
  def __getitem__(self,which='all'):
    "Get one or all items from the confusion matrix"
    assert which in self.__items__ or which == 'all'
    return self.asTuple() if which == 'all' else getattr(self,which)
  
  def __setitem__(self,which='all',args=(0,0,0,0)):
    "Set one or all items of the confusion matrix"
    assert which in self.__items__ or which == 'all'
    if which == 'all':
      [ setattr(self,slot,value) for slot, value in zip(self.__items__,args) ]
    else:
      setattr(self,which,args)
      
  def random(self,num_neg=100,num_pos=100): # only for debugging ...
    self.TN = random.randint(num_neg/2,num_neg)
    self.FP = num_neg - self.TN
    self.TP = random.randint(num_pos/2,num_pos)
    self.FN = num_pos - self.TP
    return self
  
  def inc(self,which):
    "Increment the confusion matrix"
    assert which in self.__items__
    setattr(self,which,getattr(self,which)+1)
    
  def update(self,target,output): # FP or FN if output == 0.
    "Update the confusion matrix"
    if target < 0.:
      if output < 0.: self.TN += 1
      else: self.FP += 1 
    elif target > 0.:
      if output > 0.: self.TP += 1
      else: self.FN += 1

  def asTuple(self):
    "Return the corresponding tuple as (TN, FP, FN,TP)"
    return (self.TN, self.FP, self.FN, self.TP)

  def asArray(self):
    "Return the corresponding tuple as (TN, FP, FN,TP)"
    return np.ndarray(self.asTuple())

  def eval_specificity(self):
    "Evaluate specificity"
    return self.TN / (self.TN+self.FP) if self.TN+self.FP > 0 else 0.

  def eval_sensitivity(self):
    "Evaluate sensitivity"
    return self.TP / (self.FN+self.TP) if self.FN+self.TP > 0 else 0.
  
  def eval_accuracy(self):
    "Evaluate accuracy"
    return (self.TN+self.TP) / self.all if self.all > 0 else 0.
  
  def eval_phi(self):
    "Evaluate phi"
    return self.sens - self.spec
   
  def eval_delta(self):
    "Evaluate delta"
    return self.sens + self.spec - 1.
  
  def eval_phidelta(self):
    "Evaluate phi and delta"
    return self.sens - self.spec, self.sens + self.spec - 1.

  def display(self,comment='Confusion matrix:'):
    "Display the confusion matrix"
    TN, FP, FN, TP = self.asTuple()
    spec, sens, acc = self.spec, self.sens, self.acc
    phi, delta = self.phi, self.delta
    print(comment)
    print("Neg = {} (TN = {}, FP = {})".format(TN+FP,TN,FP),end=', ')
    print("Pos = {} (FN = {}, TP = {})".format(FN+TP,FN,TP))
    formatter = "Specificity = {:4.2f}, sensitivity = {:4.2f}, accuracy = {:4.2f}, "
    formatter2 = "Phi = {:4.2f}, delta = {:4.2f}"
    print(formatter.format(spec,sens,acc), end='')
    print(formatter2.format(phi,delta))

# -----------------------------------------------------------------------------

class performance_logger(object):
  
  __all_measures__ = ('spec', 'sens', 'acc', 'phi', 'delta')

  all    = property(lambda self: [ n+p for n, p in zip(self.neg,self.pos) ])
  
  def __init__(self):
    "Init the logger"
    self.cm_list = list()
    self.num_insertions = 0

  def reset(self):
    "Reset the logger"
    self.__init__()
    
  def __lshift__(self,cm):
    "yet another cmatrix into the logger"
    self.cm_list += [ cm ]
    self.num_insertions += 1
    
  def asArray(self):  # ordering: TN, FP, FN, TP
    "Get the list of cmatrices as np.float array"
    return np.array([ cm.asTuple() for cm in self.cm_list ])
  
  def eval_cm_average(self):
    "Evaluate the mean over all TN, FP, FN, TP measures (with variance)"
    if self.num_insertions == 0: return np.array(tuple(0., 0., 0., 0.))
    #return np.mean(self.asArray(),axis=0), np.var(self.asArray(),axis=0)
    return np.mean(self.asArray(),axis=0)
  
  def performance(self,pmeasure='acc'):
    "Evaluate the wanted average performance measure (with variance)"
    if self.num_insertions == 0: return np.array(tuple(0., 0., 0., 0.))
    if pmeasure=='mean': return self.eval_mean()
    plist = np.array([ getattr(cm,pmeasure) for cm in self.cm_list ])
    return np.mean(plist), np.var(plist)

  def multi_performance(self,pmeasures='all',output='asList'):
    "Evaluate the wanted average performance measure (with variance)"
    if pmeasures == 'all': pmeasures = self.__all_measures__
    outcomes = [ self.performance(pmeas) for pmeas in pmeasures ]
    return np.array(outcomes) if output == 'asArray' else outcomes

# -----------------------------------------------------------------------------

if __name__ == '__main__':
  
  P = performance_logger()
  
  for k in range(50): P << cmatrix().random(120,90)
  
  print()
  print("Avg TN,FP,FN,TP =",P.eval_cm_average()) ; print()

  print("Avg specificity = {:+2.4f} (variance {:+2.4f})".format(*P.performance('spec')))
  print("Avg sensitivity = {:+2.4f} (variance {:+2.4f})".format(*P.performance('sens')))

  print("Avg accuracy    = {:+2.4f} (variance {:+2.4f})".format(*P.performance('acc')))

  print("Avg phi         = {:+2.4f} (variance {:+2.4f})".format(*P.performance('phi')))
  print("Avg delta       = {:+2.4f} (variance {:+2.4f})".format(*P.performance('delta'))) ; print()
  
  print("Avg multi-performance follows")
  
  results = P.multi_performance()
  
  for result in results:
    print("{:+2.4f} (var {:+2.4f})".format(*result))
    
# -----------------------------------------------------------------------------

import sys

from utils.numbers    import numeric_to_string, to_numeric

# -----------------------------------------------------------------------------

def linefeed(num=1):
  "Print a number of linefeeds (default one)"
  print('\n' * (num-1))

def remove_quoting(item):
  "Remove quoting from a string (basic version)"
  string = item if type(item) == str else str(item)
  return "".join([ ch for ch in string if ch != "'" ])
  
def printf(formatter,*args,**kwargs):
  print(formatter,*args,**kwargs)
  sys.stdout.flush()
  
def plist_as_settings(plist):
  return ", ".join([ pair_for_settings(key,val) for key,val in plist ])

def pair_for_settings(key,val):
  if type(val) is str:
    return "{}='{}'".format(key,val)
  if type(to_numeric(val)) in (int,float):
    return "{}={}".format(key,numeric_to_string(val))
  else:
    return "{}={}".format(key,val)

# -----------------------------------------------------------------------------

class stream(object):
  
  "Temporaryly redirects the standard output to file" # TO BE TESTED ...
  
  # Usage:
  #
  # stream(outfile) << any_call(any_pars)
  #    or
  # stream(outfile) << ( a_call(any_pars), another_call(...), and_so_on(...) )
  #    or
  # stream.open(outfile)
  # ... any sequence of calls ...
  # stream.close()
  
  stdout, outstream = None, None
  
  @classmethod
  def open(cls,filename):
    "Open the stream for printing"
    cls.stdout, cls.outstream = sys.stdout, None
    try: sys.stdout = cls.outstream = open(filename,"a+")
    except: sys.stdout = cls.stdout

  @classmethod
  def close(cls):
    "Close the stream"
    try: cls.outstream.close()
    finally: sys.stdout = cls.stdout

  def __init__(self,filename):
    "Init the stream (by temporarily redirecting stdout to file)"
    self.stdout, self.outstream = sys.stdout, None
    if not filename: return # output not redirected to file ...
    try: sys.stdout = self.outstream = open(filename,"a+")
    except: sys.stdout = self.stdout
    
  def __lshift__(self,*args):
    "Whatever it is printed out, it will be redirected to file"
    if not self.outstream: return # output not redirected to file ...
    try: self.outstream.close()
    finally: sys.stdout = self.stdout      
  
# -----------------------------------------------------------------------------

if __name__ == '__main__':


  stream("ciccio.txt") << (print("ciccio bello"), print("aaaahhhhh"))
  
  
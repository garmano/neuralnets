# -*- coding: utf-8 -*-
"""
Created on Thu Feb  1 11:36:08 2018

@author: armano
"""

import sys

from utils.numbers import to_numeric

# ------------------------ STRINGS, etc. --------------------------------------

def string_fix(string):
  "Remove redundant string delimiters from string, if needed"
  if not string: return
  if '\t' in string: string = string.replace('\t','')
  if string[0] == "'" and string[-1] == "'": return string.strip("'")
  if string[0] == '"' and string[-1] == '"': return string.strip('"')
  return string

def string_split(line, sep=' '):
  "Split a string according to the given separator (blanks are removed first)"
  if sep != ' ': line = "".join([c for c in line if c != ' ']) # remove blanks
  return [ string_fix(item) for item in line.split(sep) ]

def string_find(line,sub=(' ',),beg=0,end=-1):
  "Find a substring in a string (several split points can be specified)"
  for s in sub:
    ndx = line.find(s,beg,end)
    if ndx >= 0: return ndx
  return -1

def values_as_string(vslice,truncate_at=10,ftype=None):
  "Turn values (from a slice) into strings"
  if ftype == 'float': vslice = [ to_numeric(x) for x in vslice ]
  tup = tuple(set(vslice))
  if len(tup) < truncate_at: return str(tup)
  stup = tup[:truncate_at] # truncating the tuple ...
  return str(stup)[:-1] + " ... )" # removing the trailing round bracket, etc.

def strip_multiple(*strings):
  "Multiple strip"
  return [ s.strip() if type(s) == str else s for s in strings ]
  
def strip_string(string,blacklist):
  return "".join([ ch for ch in string if not ch in blacklist ])

def find_substring(string,substring,skip=0):
  ndx = -1
  for k in range(skip+1): ndx = string.find(substring,ndx+1)
  return string[ndx:]
  
# -----------------------------------------------------------------------------

def conditional_eval(string,stype=str):
  "Conditionally evaluates a string"
  if stype == str:
    if len(string) == 0: return string
    if string[0] == "'": return eval(string)
    if string[0] == '"': return eval(string)
  if stype in (tuple,list,dict): return eval(string)
  if stype == bool: return string == 'True'
  if stype == type(None): return string
  return stype(string)

def str2class(classname,module):
  "Getting a class object from its name"
  return getattr(sys.modules[module], classname)

# -----------------------------------------------------------------------------
